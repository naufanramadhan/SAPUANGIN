function results = calculate_dynamics(params, T_sweep)
% CALCULATE_DYNAMICS
% Menghitung seluruh parameter dinamika kendaraan pada setiap nilai
% Front Track Width dalam vektor T_sweep.
%
% Input:
%   params   : Struct parameter baseline dari read_vehicle_params()
%   T_sweep  : Vektor front track width yang akan di-sweep [mm]
%
% Output:
%   results  : Struct berisi vektor hasil perhitungan sepanjang T_sweep

n = length(T_sweep);

% Pre-alokasi output
results.T_f            = T_sweep;

% Load Transfer
results.Delta_W_F      = zeros(1,n);   % Front axle total load transfer [N]
results.Delta_W_R      = zeros(1,n);   % Rear axle total load transfer [N]
results.Delta_W_total  = zeros(1,n);   % Total load transfer [N]
results.Fz_fi          = zeros(1,n);   % Front inner wheel normal load [N]
results.Fz_fo          = zeros(1,n);   % Front outer wheel normal load [N]

% Grip
results.Fy_f           = zeros(1,n);   % Front axle lateral force [N]
results.Fy_r           = zeros(1,n);   % Rear axle lateral force [N]
results.Fy_total       = zeros(1,n);   % Total lateral grip [N]
results.Ay_max         = zeros(1,n);   % Max lateral acceleration [g]

% Roll
results.K_phi_f        = zeros(1,n);   % Front roll stiffness [Nm/deg]
results.K_phi_r        = zeros(1,n);   % Rear roll stiffness [Nm/deg]
results.K_phi_total    = zeros(1,n);   % Total roll stiffness [Nm/deg]
results.phi_roll       = zeros(1,n);   % Body roll angle at A_y target [deg]
results.phi_per_Ay     = zeros(1,n);   % Roll gradient [deg/g]

% Camber
results.L_FVSA_f       = zeros(1,n);   % Front FVSA length [mm]
results.dgamma_dphi_f  = zeros(1,n);   % Front camber gain [deg/deg]
results.delta_gamma_f  = zeros(1,n);   % Dynamic camber change at A_y [deg]

% Steering / Ackermann
results.delta_i        = zeros(1,n);   % Inner wheel steer angle [deg]
results.delta_o        = zeros(1,n);   % Outer wheel steer angle [deg]
results.Delta_delta    = zeros(1,n);   % Ackermann angle delta [deg]
results.M_kickback     = zeros(1,n);   % Steering kickback torque [Nm]

% Structural
results.SF_lower_f     = zeros(1,n);   % Front lower wishbone buckling SF [-]
results.P_crit_f       = zeros(1,n);   % Critical Euler buckling load front [N]
results.K_chassis_req  = zeros(1,n);   % Required chassis torsional stiffness [Nm/deg]

% =========================================================
% KONSTANTA YANG TIDAK BERGANTUNG PADA T_f SWEEP
% =========================================================
g       = params.g;
m_s     = params.m_s;
m_uf    = params.m_uf;
m_ur    = params.m_ur;
h_s     = params.h_s;          % Sprung CG height [mm]
h_uf    = params.h_uf;
h_ur    = params.h_ur;
T_r     = params.T_r;          % Rear trackwidth tetap [mm]
WD_f    = params.WD_f;
z_RF    = params.z_RF;
z_RR    = params.z_RR;
A_y     = params.A_y;          % Target lateral acceleration [g]
L       = params.L;            % Wheelbase [mm]
R_c     = params.R_corner * 1000; % Corner radius [mm]
W_total = params.W_total;      % [N]

% Wheel stiffness rates (konstan, tidak bergantung T_f)
K_Wf    = params.K_sf * params.IR_f^2;             % Front wheel rate [N/mm]
K_Wr    = params.K_sr * params.IR_r^2;             % Rear wheel rate [N/mm]
K_tf    = params.K_tf;                              % Front tire vertical stiffness [N/mm]
K_tr    = params.K_tr;                              % Rear tire vertical stiffness [N/mm]
K_Rf    = (K_Wf * K_tf) / (K_Wf + K_tf);          % Front ride rate [N/mm]
K_Rr    = (K_Wr * K_tr) / (K_Wr + K_tr);          % Rear ride rate [N/mm]
K_arbf  = params.K_arbf;                           % Front ARB [Nm/deg]
K_arbr  = params.K_arbr;                           % Rear ARB [Nm/deg]

% Rear roll stiffness (konstan karena T_r konstan)
K_phi_r_const = (T_r^2 * K_Rr) / 114600 + K_arbr; % [Nm/deg]

% Rear axle static weight
W_r     = W_total * (1 - WD_f);                    % [N]

% Roll axis height at CG (fungsi WD_f konstan)
z_RA    = z_RF + (z_RR - z_RF) * (1 - WD_f);      % [mm]
h_a     = h_s - z_RA;                              % Roll moment arm [mm]

% Rear static load per wheel
W_r_wheel = W_r / 2;                               % [N]

% Rear unsprung load transfer (konstan karena T_r konstan)
Delta_W_ur_const = A_y * m_ur * g * (h_ur / T_r); % [N]

% Rear geometric load transfer (konstan)
Delta_W_sfr_const = A_y * m_s * g * (1 - WD_f) * (z_RR / T_r); % [N]

% Tire friction model (non-linear) - rear (konstan)
mu_0r    = params.mu_0r;
dmu_r    = params.dmu_dFz_r;
F_z0r    = params.F_z0r;

% Structural tube properties (konstan)
E       = params.E_modulus;    % [MPa = N/mm^2]
I_tube  = params.I_tube;       % [mm^4]

% =========================================================
% SWEEP LOOP UTAMA
% =========================================================
for i = 1:n
    Tf = T_sweep(i);  % Current front track width [mm]

    % --- FRONT AXLE STATIC WEIGHT ---
    W_f       = W_total * WD_f;            % [N]
    W_f_wheel = W_f / 2;                   % [N]

    % --- WISHBONE LENGTH (proporsional dengan T_f) ---
    % Asumsi: arm diperpanjang proporsional dengan T_f
    L_lower_f = params.L_lower_f * (Tf / params.T_f);   % [mm]

    % --- FRONT VIEW SWING ARM (FVSA) ---
    if abs(1 - params.Ratio_UL_f) > 1e-6
        L_FVSA_f = L_lower_f / (1 - params.Ratio_UL_f);
    else
        L_FVSA_f = 1e6; % Parallel arms: infinite FVSA
    end
    results.L_FVSA_f(i) = L_FVSA_f;

    % --- CAMBER GAIN RATE IN ROLL ---
    dgamma_dphi_f = (h_s - z_RF) / L_FVSA_f;          % [deg/deg] (dimensionless)
    results.dgamma_dphi_f(i) = dgamma_dphi_f;

    % --- FRONT ROLL STIFFNESS ---
    K_phi_f = (Tf^2 * K_Rf) / 114600 + K_arbf;        % [Nm/deg]
    results.K_phi_f(i) = K_phi_f;

    % --- TOTAL ROLL STIFFNESS ---
    K_phi_total = K_phi_f + K_phi_r_const;             % [Nm/deg]
    results.K_phi_r(i)     = K_phi_r_const;
    results.K_phi_total(i) = K_phi_total;

    % --- ROLL MOMENT & ROLL ANGLE ---
    M_R        = m_s * g * A_y * (h_a / 1000);        % [Nm]
    phi_per_Ay = M_R / K_phi_total / A_y;              % [deg/g]
    phi_roll   = phi_per_Ay * A_y;                     % [deg]
    results.phi_per_Ay(i) = phi_per_Ay;
    results.phi_roll(i)   = phi_roll;

    % --- DYNAMIC CAMBER CHANGE ---
    delta_gamma_f = dgamma_dphi_f * phi_roll;          % [deg]
    results.delta_gamma_f(i) = delta_gamma_f;

    % --- FRONT LOAD TRANSFER ---
    Delta_W_uf  = A_y * m_uf * g * (h_uf / Tf);       % Unsprung [N]
    Delta_W_sff = A_y * m_s * g * WD_f * (z_RF / Tf); % Geometric [N]
    Delta_W_scf = (K_phi_f / K_phi_total) * M_R / (Tf / 1000); % Elastic [N]
    Delta_W_F   = Delta_W_uf + Delta_W_sff + Delta_W_scf;      % Total [N]
    results.Delta_W_F(i) = Delta_W_F;

    % --- REAR LOAD TRANSFER ---
    Delta_W_scr = (K_phi_r_const / K_phi_total) * M_R / (T_r / 1000); % [N]
    Delta_W_R   = Delta_W_ur_const + Delta_W_sfr_const + Delta_W_scr;  % [N]
    results.Delta_W_R(i)     = Delta_W_R;
    results.Delta_W_total(i) = Delta_W_F + Delta_W_R;

    % --- NORMAL LOADS PER WHEEL ---
    Fz_fo = W_f_wheel + Delta_W_F;   % Front outer [N]
    Fz_fi = W_f_wheel - Delta_W_F;   % Front inner [N]
    results.Fz_fo(i) = Fz_fo;
    results.Fz_fi(i) = Fz_fi;

    % --- TIRE GRIP (Non-linear Friction Model) ---
    % F_y = mu(Fz) * Fz,  mu(Fz) = mu_0 + dmu_dFz * (Fz - Fz0)
    mu_0f = params.mu_0f;
    dmu_f = params.dmu_dFz_f;
    F_z0f = params.F_z0f;

    % Front: Clamp load agar tidak negatif
    Fz_fi_grip = max(Fz_fi, 0);
    mu_fi  = mu_0f + dmu_f * (Fz_fi_grip - F_z0f);
    mu_fo  = mu_0f + dmu_f * (Fz_fo - F_z0f);
    mu_fi  = max(mu_fi, 0);
    mu_fo  = max(mu_fo, 0);
    Fy_f   = mu_fi * Fz_fi_grip + mu_fo * Fz_fo;

    % Rear: normal load
    Fz_ro = W_r_wheel + Delta_W_R;
    Fz_ri = W_r_wheel - Delta_W_R;
    Fz_ri_grip = max(Fz_ri, 0);
    mu_ri  = mu_0r + dmu_r * (Fz_ri_grip - F_z0r);
    mu_ro  = mu_0r + dmu_r * (Fz_ro - F_z0r);
    mu_ri  = max(mu_ri, 0);
    mu_ro  = max(mu_ro, 0);
    Fy_r   = mu_ri * Fz_ri_grip + mu_ro * Fz_ro;

    results.Fy_f(i)     = Fy_f;
    results.Fy_r(i)     = Fy_r;
    results.Fy_total(i) = Fy_f + Fy_r;
    results.Ay_max(i)   = (Fy_f + Fy_r) / W_total;    % [g]

    % --- ACKERMANN STEERING ---
    delta_i = atan2d(L, (R_c - Tf/2));    % Inner wheel [deg]
    delta_o = atan2d(L, (R_c + Tf/2));    % Outer wheel [deg]
    results.delta_i(i)     = delta_i;
    results.delta_o(i)     = delta_o;
    results.Delta_delta(i) = delta_i - delta_o;

    % --- KICKBACK TORQUE ---
    results.M_kickback(i) = Fy_f * (params.R_scrub_f / 1000); % [Nm]

    % --- EULER BUCKLING SAFETY FACTOR (Front Lower Wishbone) ---
    P_comp_f   = (Fy_f / 2) * 1.5;                         % Peak compression [N]
    P_crit_f   = (pi^2 * E * I_tube) / (L_lower_f^2);      % Euler critical load [N]
    SF_lower_f = P_crit_f / max(P_comp_f, 1e-6);           % Safety factor [-]
    results.P_crit_f(i)    = P_crit_f;
    results.SF_lower_f(i)  = SF_lower_f;

    % --- REQUIRED CHASSIS TORSIONAL STIFFNESS ---
    results.K_chassis_req(i) = 1.2 * K_phi_total;          % [Nm/deg]
end

% =========================================================
% RINGKASAN TITIK BASELINE & OPTIMAL
% =========================================================
results.baseline_idx = find(T_sweep == params.T_f, 1);
if isempty(results.baseline_idx)
    [~, results.baseline_idx] = min(abs(T_sweep - params.T_f));
end

% Cari track width optimal: Ay_max tertinggi dengan SF >= 1.5
valid_mask = results.SF_lower_f >= 1.5;
if any(valid_mask)
    valid_Ay = results.Ay_max;
    valid_Ay(~valid_mask) = -Inf;
    [~, results.optimal_idx] = max(valid_Ay);
else
    [~, results.optimal_idx] = max(results.Ay_max);
    warning('Tidak ada track width yang memenuhi SF >= 1.5!');
end

results.T_optimal   = T_sweep(results.optimal_idx);
results.Ay_optimal  = results.Ay_max(results.optimal_idx);

end