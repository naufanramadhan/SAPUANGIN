function results = calculate_four_wheel(params, T_sweep, config)
% CALCULATE_FOUR_WHEEL Four contact patch vehicle dynamics over a track sweep.
%
% Linear range handling model with four explicit tyre contact patches:
%   FL = front left   FR = front right
%   RL = rear left    RR = rear right
%
% Assumptions kept explicit so they can be checked against the vehicle:
%   * lateral load transfer uses roll stiffness distribution between axles
%   * longitudinal transfer uses the declared acceleration level
%   * tyre cornering capacity uses the Excel nonlinear load sensitivity
%   * a sliding scale factor represents lateral to longitudinal capacity loss

n = length(T_sweep);
g = params.g;
mm_per_m = 1000;
deg_per_rad = 180 / pi;

% ---- constants independent of track width ----
m_uf = params.m_uf;
m_ur = params.m_ur;
h_uf = params.h_uf;
h_ur = params.h_ur;
h_s = params.h_s;
z_RF = params.z_RF;
z_RR = params.z_RR;
WD_f = params.WD_f;
L = params.L;
W_total = params.W_total;

K_Wf = params.K_sf * params.IR_f^2;
K_Wr = params.K_sr * params.IR_r^2;
K_Rf = (K_Wf * params.K_tf) / (K_Wf + params.K_tf);
K_Rr = (K_Wr * params.K_tr) / (K_Wr + params.K_tr);

z_RA = z_RF + (z_RR - z_RF) * (1 - WD_f);
h_a = h_s - z_RA;
M_R_per_Ay = params.m_s * g * (h_a / mm_per_m);   % [Nm per g]

mu_0f = params.mu_0f; dmu_f = params.dmu_dFz_f; F_z0f = params.F_z0f;
mu_0r = params.mu_0r; dmu_r = params.dmu_dFz_r; F_z0r = params.F_z0r;

% tyre grip helper (vectorised over load)
grip = @(mu_0, dmu, F_z0, Fz) max(mu_0 + dmu .* (max(Fz, 0) - F_z0), 0) .* max(Fz, 0);

results.T_f = T_sweep;
results.T_r = zeros(1, n);

% four patch loads
results.Fz_FL = zeros(1, n); results.Fz_FR = zeros(1, n);
results.Fz_RL = zeros(1, n); results.Fz_RR = zeros(1, n);

% individual tyre capacity and utilisation
results.Fy_FL = zeros(1, n); results.Fy_FR = zeros(1, n);
results.Fy_RL = zeros(1, n); results.Fy_RR = zeros(1, n);
results.util_FL = zeros(1, n); results.util_FR = zeros(1, n);
results.util_RL = zeros(1, n); results.util_RR = zeros(1, n);

results.Delta_W_F = zeros(1, n);
results.Delta_W_R = zeros(1, n);
results.K_phi_f = zeros(1, n);
results.K_phi_r = zeros(1, n);
results.K_phi_total = zeros(1, n);
results.phi_roll_at_target = zeros(1, n);

results.Fy_front = zeros(1, n);
results.Fy_rear = zeros(1, n);
results.Fy_total = zeros(1, n);
results.Ay_capacity = zeros(1, n);
results.Ay_balance = zeros(1, n);

results.lift_off_front = false(1, n);
results.lift_off_rear = false(1, n);

results.L_lower_f = zeros(1, n);
results.SF_lower_f = zeros(1, n);
results.delta_i = zeros(1, n);
results.delta_o = zeros(1, n);
results.cv_angle_deg = zeros(1, n);

A_y = params.A_y;               % baseline lateral acceleration level [g]
E = params.E_modulus;
I_tube = params.I_tube;

for i = 1:n
    Tf = T_sweep(i);
    Tr = rear_track_for(Tf);

    % axle static loads
    W_f = W_total * WD_f;  W_fw = W_f / 2;
    W_r = W_total * (1 - WD_f);  W_rw = W_r / 2;

    % roll stiffness distribution
    K_phi_f = (Tf^2 * K_Rf) / ...
        (2 * deg_per_rad * mm_per_m) + params.K_arbf;
    K_phi_r = (Tr^2 * K_Rr) / ...
        (2 * deg_per_rad * mm_per_m) + params.K_arbr;
    K_phi_tot = K_phi_f + K_phi_r;
    results.K_phi_f(i) = K_phi_f;
    results.K_phi_r(i) = K_phi_r;
    results.K_phi_total(i) = K_phi_tot;

    % lateral load transfer: unsprung + geometric + elastic
    dW_uf = A_y * m_uf * g * (h_uf / Tf);
    dW_sf = A_y * params.m_s * g * WD_f * (z_RF / Tf);
    dW_ef = (K_phi_f / K_phi_tot) * M_R_per_Ay * A_y / ...
        (Tf / mm_per_m);
    dW_F = dW_uf + dW_sf + dW_ef;

    dW_ur = A_y * m_ur * g * (h_ur / Tr);
    dW_sr = A_y * params.m_s * g * (1 - WD_f) * (z_RR / Tr);
    dW_er = (K_phi_r / K_phi_tot) * M_R_per_Ay * A_y / ...
        (Tr / mm_per_m);
    dW_R = dW_ur + dW_sr + dW_er;

    results.Delta_W_F(i) = dW_F;
    results.Delta_W_R(i) = dW_R;

    Fz_FL = W_fw - dW_F;
    Fz_FR = W_fw + dW_F;
    Fz_RL = W_rw - dW_R;
    Fz_RR = W_rw + dW_R;
    results.Fz_FL(i) = Fz_FL; results.Fz_FR(i) = Fz_FR;
    results.Fz_RL(i) = Fz_RL; results.Fz_RR(i) = Fz_RR;

    results.lift_off_front(i) = min(Fz_FL, Fz_FR) <= 0;
    results.lift_off_rear(i) = min(Fz_RL, Fz_RR) <= 0;

    % individual tyre grip capacity at the baseline load condition
    Fy_FL = grip(mu_0f, dmu_f, F_z0f, Fz_FL);
    Fy_FR = grip(mu_0f, dmu_f, F_z0f, Fz_FR);
    Fy_RL = grip(mu_0r, dmu_r, F_z0r, Fz_RL);
    Fy_RR = grip(mu_0r, dmu_r, F_z0r, Fz_RR);
    results.Fy_FL(i) = Fy_FL; results.Fy_FR(i) = Fy_FR;
    results.Fy_RL(i) = Fy_RL; results.Fy_RR(i) = Fy_RR;

    results.util_FL(i) = utilisation(Fy_FL, Fz_FL, mu_0f, dmu_f, F_z0f);
    results.util_FR(i) = utilisation(Fy_FR, Fz_FR, mu_0f, dmu_f, F_z0f);
    results.util_RL(i) = utilisation(Fy_RL, Fz_RL, mu_0r, dmu_r, F_z0r);
    results.util_RR(i) = utilisation(Fy_RR, Fz_RR, mu_0r, dmu_r, F_z0r);

    results.Fy_front(i) = Fy_FL + Fy_FR;
    results.Fy_rear(i) = Fy_RL + Fy_RR;
    results.Fy_total(i) = Fy_FL + Fy_FR + Fy_RL + Fy_RR;
    results.Ay_capacity(i) = solve_lateral_capacity(Tf, Tr, ...
        K_phi_f, K_phi_r, K_phi_tot);
    results.Ay_balance(i) = results.Fy_rear(i) / max(results.Fy_front(i), 1e-6);

    % roll angle at the Excel target lateral acceleration
    results.phi_roll_at_target(i) = (M_R_per_Ay * A_y) / K_phi_tot;

    % steering geometry
    R_c = params.R_corner * 1000;   % mm
    results.delta_i(i) = atan2d(L, R_c - Tf / 2);
    results.delta_o(i) = atan2d(L, R_c + Tf / 2);

    % structural: front lower wishbone buckling
    L_lower = params.L_lower_f * (Tf / params.T_f);
    results.L_lower_f(i) = L_lower;
    P_comp = (results.Fy_front(i) / 2) * config.structural_load_factor;
    P_crit = (pi^2 * E * I_tube) / (L_lower^2);
    results.SF_lower_f(i) = P_crit / max(P_comp, 1e-6);

    % drive shaft angle from track widening
    half_shaft_geom = params.L_halfshaft + (Tr - params.T_r) / 2;
    results.cv_angle_deg(i) = atand(max((Tr - params.T_r) / 2, 0) / max(params.L_halfshaft, 1e-6));
    results.T_r(i) = Tr;
    results.half_shaft_mm(i) = max(half_shaft_geom, 1);
end

results.baseline_idx = find_closest(results.T_f, params.T_f);
results.Fy_balance = results.Ay_balance;

% Rear track strategy from configuration
    function Tr = rear_track_for(Tf)
        switch config.rear_track_delta_mode
            case 'preserve_difference'
                Tr = Tf + (params.T_r - params.T_f);
            case 'identical_absolute'
                Tr = Tf;
            case 'fixed'
                Tr = params.T_r;
            otherwise
                error('Mode rear track tidak dikenal: %s', config.rear_track_delta_mode);
        end
    end

    function Ay_capacity = solve_lateral_capacity(Tf, Tr, Kf, Kr, Ktotal)
        capacity_residual = @(Ay) grip_capacity_at(Ay, Tf, Tr, ...
            Kf, Kr, Ktotal) / W_total - Ay;
        upper_Ay = max(params.A_y, 1);
        while capacity_residual(upper_Ay) > 0
            upper_Ay = 2 * upper_Ay;
        end
        Ay_capacity = fzero(capacity_residual, [0, upper_Ay]);
    end

    function total_grip = grip_capacity_at(Ay, Tf, Tr, Kf, Kr, Ktotal)
        dWf = Ay * m_uf * g * (h_uf / Tf) + ...
            Ay * params.m_s * g * WD_f * (z_RF / Tf) + ...
            (Kf / Ktotal) * M_R_per_Ay * Ay / (Tf / mm_per_m);
        dWr = Ay * m_ur * g * (h_ur / Tr) + ...
            Ay * params.m_s * g * (1 - WD_f) * (z_RR / Tr) + ...
            (Kr / Ktotal) * M_R_per_Ay * Ay / (Tr / mm_per_m);

        front_wheel_load = W_total * WD_f / 2;
        rear_wheel_load = W_total * (1 - WD_f) / 2;
        total_grip = ...
            grip(mu_0f, dmu_f, F_z0f, front_wheel_load - dWf) + ...
            grip(mu_0f, dmu_f, F_z0f, front_wheel_load + dWf) + ...
            grip(mu_0r, dmu_r, F_z0r, rear_wheel_load - dWr) + ...
            grip(mu_0r, dmu_r, F_z0r, rear_wheel_load + dWr);
    end
end

function idx = find_closest(vec, target)
[~, idx] = min(abs(vec - target));
end

function u = utilisation(Fy, Fz, mu_0, dmu, F_z0)
cap = max(mu_0 + dmu * (max(Fz, 0) - F_z0), 0);
if cap <= 0 || Fz <= 0
    u = 0;
else
    u = Fy / (cap * Fz);
end
end
