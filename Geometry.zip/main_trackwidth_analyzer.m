%% ========================================================================
%  MAIN_TRACKWIDTH_ANALYZER.m
%  FSAE Vehicle Dynamics — Front Track Width Parametric Optimizer
%  -----------------------------------------------------------------------
%  Cara Pakai:
%    1. Ubah nilai baseline di file Excel (Sheet: 02_INPUT_VARIABLES, Kolom E)
%    2. SAVE file Excel
%    3. Jalankan script ini di MATLAB: >> main_trackwidth_analyzer
%    4. Grafik dan ringkasan analitik akan ter-update otomatis
%  -----------------------------------------------------------------------
%  File dependencies:
%    read_vehicle_params.m   — Pembaca Excel real-time
%    calculate_dynamics.m    — Engine perhitungan dinamika
%    plot_results.m          — Visualisasi dashboard grafik
%  ========================================================================

clc; clear; close all;

script_dir = fileparts(mfilename('fullpath'));
run_jsae_four_wheel_analysis(script_dir);
return;

%% -----------------------------------------------------------------------
%  KONFIGURASI: Sesuaikan path Excel jika diperlukan
%  -----------------------------------------------------------------------
EXCEL_FILE = 'FSAE_VD_3_KASAR .xlsx';  % Nama file (harus di folder yang sama)
                                          % Atau ganti dengan full path, contoh:
                                          % EXCEL_FILE = 'C:\Users\LOQ\SAPANG\SAS 9\GEOMETRY\FSAE_VD_3_KASAR .xlsx';

% Range Sweep Front Track Width [mm] (ubah sesuai kebutuhan)
T_SWEEP_MIN  = 1200;   % mm
T_SWEEP_MAX  = 1280;   % mm
T_SWEEP_STEP = 5;      % mm (resolusi lebih halus = lebih presisi)

%% -----------------------------------------------------------------------
%  HEADER
%  -----------------------------------------------------------------------
fprintf('\n');
fprintf('========================================================\n');
fprintf(' FSAE Vehicle Dynamics — Track Width Optimization Tool \n');
fprintf(' Versi 1.0 | %s\n', datestr(now, 'dd-mmm-yyyy HH:MM:SS'));
fprintf('========================================================\n');

%% -----------------------------------------------------------------------
%  STEP 1: Temukan file Excel & baca parameter baseline
%  -----------------------------------------------------------------------
% Resolve path absolut file Excel
if ~isfile(EXCEL_FILE)
    % Coba cari di folder script ini
    script_dir = fileparts(mfilename('fullpath'));
    candidate  = fullfile(script_dir, EXCEL_FILE);
    if isfile(candidate)
        EXCEL_FILE = candidate;
    else
        error(['[ERROR] File Excel tidak ditemukan: %s\n' ...
               'Pastikan file Excel berada di folder yang sama dengan script ini,\n' ...
               'atau ubah variabel EXCEL_FILE dengan full path yang benar.'], EXCEL_FILE);
    end
end

fprintf('\n[STEP 1] Membaca parameter dari Excel...\n');
t_read = tic;
params = read_vehicle_params(EXCEL_FILE);
fprintf('>> Waktu baca Excel: %.2f detik\n', toc(t_read));

%% -----------------------------------------------------------------------
%  STEP 2: Jalankan sweep parametrik
%  -----------------------------------------------------------------------
T_sweep = T_SWEEP_MIN : T_SWEEP_STEP : T_SWEEP_MAX;

fprintf('\n[STEP 2] Menjalankan parametric sweep...\n');
fprintf('  >> Range   : %d mm — %d mm\n', T_SWEEP_MIN, T_SWEEP_MAX);
fprintf('  >> Step    : %d mm\n', T_SWEEP_STEP);
fprintf('  >> Jumlah titik: %d\n', length(T_sweep));

t_calc = tic;
results = calculate_dynamics(params, T_sweep);
fprintf('>> Waktu komputasi: %.4f detik\n', toc(t_calc));

%% -----------------------------------------------------------------------
%  STEP 3: Tampilkan ringkasan analitik di Command Window
%  -----------------------------------------------------------------------
i_b = results.baseline_idx;
i_o = results.optimal_idx;
T_o = results.T_optimal;

fprintf('\n========================================================\n');
fprintf('   RINGKASAN HASIL ANALISIS\n');
fprintf('========================================================\n');
fprintf('%-38s %10s %10s %10s\n', 'Parameter', 'Baseline', 'Optimal', 'Delta');
fprintf('%s\n', repmat('-', 1, 72));

print_row = @(label, unit, v_b, v_o) ...
    fprintf('%-38s %9.3f%s %9.3f%s %+9.3f%s\n', ...
            label, v_b, unit, v_o, unit, v_o - v_b, unit);

fprintf('  Track Width T_f\n');
fprintf('   %-36s %9.0f mm  %9.0f mm  %+9.0f mm\n', ...
        '', params.T_f, T_o, T_o - params.T_f);
fprintf('%s\n', repmat('-', 1, 72));

fprintf('  [LOAD TRANSFER]\n');
print_row('   Total Front Load Transfer DW_F', ' N',  results.Delta_W_F(i_b),    results.Delta_W_F(i_o));
print_row('   Total Rear Load Transfer DW_R',  ' N',  results.Delta_W_R(i_b),    results.Delta_W_R(i_o));
print_row('   Front Inner Wheel Load Fz_fi',   ' N',  results.Fz_fi(i_b),        results.Fz_fi(i_o));

if results.Fz_fi(i_b) < 0
    fprintf('   !! PERINGATAN: Baseline inner wheel LIFT-OFF terdeteksi!\n');
end
if results.Fz_fi(i_o) < 0
    fprintf('   !! PERINGATAN: Optimal inner wheel LIFT-OFF terdeteksi!\n');
else
    fprintf('   >> Inner wheel load (Optimal): OK (%.1f N > 0)\n', results.Fz_fi(i_o));
end

fprintf('%s\n', repmat('-', 1, 72));
fprintf('  [GRIP & ACCELERATION]\n');
print_row('   Total Lateral Grip SumFy',       ' N',  results.Fy_total(i_b),     results.Fy_total(i_o));
print_row('   Max Lateral Acceleration Ay_max', ' g',  results.Ay_max(i_b),       results.Ay_max(i_o));
grip_gain_pct = (results.Fy_total(i_o) / results.Fy_total(i_b) - 1) * 100;
fprintf('   >> Grip Gain (Optimal vs Baseline): %+.2f%%\n', grip_gain_pct);

fprintf('%s\n', repmat('-', 1, 72));
fprintf('  [ROLL DYNAMICS]\n');
print_row('   Front Roll Stiffness K_phi_f',   ' Nm/deg', results.K_phi_f(i_b),   results.K_phi_f(i_o));
print_row('   Total Roll Stiffness K_phi_tot', ' Nm/deg', results.K_phi_total(i_b),results.K_phi_total(i_o));
print_row('   Body Roll Angle phi_roll',        ' deg',   results.phi_roll(i_b),   results.phi_roll(i_o));
print_row('   Dynamic Camber Loss delta_gamma', ' deg',   results.delta_gamma_f(i_b), results.delta_gamma_f(i_o));

fprintf('%s\n', repmat('-', 1, 72));
fprintf('  [STEERING]\n');
print_row('   Ackermann Delta_delta',           ' deg',   results.Delta_delta(i_b), results.Delta_delta(i_o));
print_row('   Kickback Torque M_kickback',      ' Nm',    results.M_kickback(i_b),  results.M_kickback(i_o));

fprintf('%s\n', repmat('-', 1, 72));
fprintf('  [STRUCTURAL]\n');
print_row('   Wishbone Buckling SF (Front)',    ' -',     results.SF_lower_f(i_b),  results.SF_lower_f(i_o));
print_row('   Chassis Stiffness Target',        ' Nm/deg',results.K_chassis_req(i_b),results.K_chassis_req(i_o));

if results.SF_lower_f(i_b) >= 1.5
    fprintf('   >> Baseline Buckling SF: AMAN (%.2f >= 1.5)\n', results.SF_lower_f(i_b));
else
    fprintf('   !! Baseline Buckling SF: TIDAK AMAN (%.2f < 1.5)!\n', results.SF_lower_f(i_b));
end
if results.SF_lower_f(i_o) >= 1.5
    fprintf('   >> Optimal Buckling SF:  AMAN (%.2f >= 1.5)\n', results.SF_lower_f(i_o));
else
    fprintf('   !! Optimal Buckling SF:  TIDAK AMAN (%.2f < 1.5)!\n', results.SF_lower_f(i_o));
end

fprintf('%s\n', repmat('-', 1, 72));
fprintf('\n  [REKOMENDASI]\n');
fprintf('   >> Track Width Optimal: %.0f mm (grip tertinggi, SF >= 1.5)\n', T_o);
fprintf('   >> Delta dari Baseline: %+.0f mm\n', T_o - params.T_f);
fprintf('   >> Peningkatan Ay_max : %+.4f g (%+.2f%%)\n', ...
        results.Ay_max(i_o) - results.Ay_max(i_b), ...
        (results.Ay_max(i_o)/results.Ay_max(i_b) - 1)*100);
fprintf('\n========================================================\n\n');

%% -----------------------------------------------------------------------
%  STEP 4: Buat grafik
%  -----------------------------------------------------------------------
fprintf('[STEP 4] Membuat grafik visualisasi...\n');
t_plot = tic;
plot_results(results, params);
fprintf('>> Waktu render: %.2f detik\n', toc(t_plot));

fprintf('\n>> [SELESAI] Analisis berhasil diselesaikan.\n');
fprintf('   Ubah nilai di Excel --> Save --> Jalankan ulang script ini.\n\n');
