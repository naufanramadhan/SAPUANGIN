function output_file = plot_jsae_results(geom, vehicle, lap, params, config, output_dir, timestamp)
% PLOT_JSAE_RESULTS Create the four-wheel track-width trade-off dashboard.

baseline_id = lap.baseline_idx;
optimal_id = lap.optimal_idx;
distance = geom.distance_m;

fig = figure('Name', 'FSAE Japan Four-Wheel Track Width Analysis', ...
    'NumberTitle', 'off', 'Color', 'white', ...
    'Position', [40, 40, 1500, 920]);
layout = tiledlayout(fig, 2, 3, 'TileSpacing', 'compact', ...
    'Padding', 'compact');

nexttile;
scatter(geom.xy_m(:, 1), geom.xy_m(:, 2), 18, ...
    lap.speed_mps(:, optimal_id) * 3.6, 'filled');
axis equal; grid on; box on;
xlabel('X [m]'); ylabel('Y [m]');
title(sprintf('JSAE Racing Line: Speed at %.0f mm', ...
    vehicle.T_f(optimal_id)));
speed_colorbar = colorbar;
speed_colorbar.Label.String = 'Speed [km/h]';

nexttile;
hold on; grid on; box on;
plot(vehicle.T_f, lap.lap_time_s, 'k-', 'LineWidth', 2);
plot(vehicle.T_f(baseline_id), lap.lap_time_s(baseline_id), 'o', ...
    'MarkerSize', 9, 'MarkerFaceColor', [0.15, 0.45, 0.80]);
plot(vehicle.T_f(optimal_id), lap.lap_time_s(optimal_id), 's', ...
    'MarkerSize', 9, 'MarkerFaceColor', [0.85, 0.25, 0.15]);
xlabel('Front Track Width [mm]'); ylabel('Estimated Lap Time [s]');
title('Track Width Trade-Off');
legend('Sweep', 'Baseline', 'Minimum Valid Lap', 'Location', 'best');

nexttile;
yyaxis left
plot(vehicle.T_f, vehicle.Ay_capacity, '-', 'LineWidth', 2);
ylabel('Self-Consistent Lateral Capacity [g]');
yyaxis right
plot(vehicle.T_f, lap.yaw_inertia_kgm2, '--', 'LineWidth', 2);
ylabel('Estimated Yaw Inertia [kg m^2]');
grid on; box on; xlabel('Front Track Width [mm]');
title('Grip Benefit vs Yaw Inertia');

nexttile;
hold on; grid on; box on;
plot(distance, lap.speed_mps(:, baseline_id) * 3.6, ...
    'LineWidth', 1.6);
plot(distance, lap.speed_mps(:, optimal_id) * 3.6, ...
    'LineWidth', 1.6);
xlabel('Distance [m]'); ylabel('Speed [km/h]');
title('Closed-Loop Speed Profile');
legend(sprintf('Baseline %.0f mm', vehicle.T_f(baseline_id)), ...
    sprintf('Optimal %.0f mm', vehicle.T_f(optimal_id)), ...
    'Location', 'best');

nexttile;
hold on; grid on; box on;
wheel_labels = {'FL', 'FR', 'RL', 'RR'};
for wheel_id = 1:4
    plot(distance, lap.wheel_load_N(wheel_id, :, optimal_id), ...
        'LineWidth', 1.2, 'DisplayName', wheel_labels{wheel_id});
end
yline(0, 'k--', 'Wheel lift threshold');
xlabel('Distance [m]'); ylabel('Normal Load [N]');
title('Four Contact-Patch Loads at Optimum');
legend('Location', 'best');

nexttile;
hold on; grid on; box on;
yyaxis left
plot(vehicle.T_f, lap.corridor_clearance_m, '-', 'LineWidth', 2);
ylabel('Lateral Corridor per Side [m]');
yyaxis right
plot(vehicle.T_f, vehicle.SF_lower_f, '--', 'LineWidth', 2);
yline(config.minimum_buckling_sf, ':', ...
    sprintf('Minimum SF = %.2f', config.minimum_buckling_sf));
ylabel('Wishbone Buckling SF [-]');
xlabel('Front Track Width [mm]');
title('Course Clearance and Structural Constraint');

title(layout, sprintf(['FSAE Japan Four-Wheel Track Width Analysis | ' ...
    'm = %.1f kg | Baseline %.0f mm: %.3f s | Optimal %.0f mm: %.3f s'], ...
    params.m_total, vehicle.T_f(baseline_id), ...
    lap.lap_time_s(baseline_id), vehicle.T_f(optimal_id), ...
    lap.lap_time_s(optimal_id)), 'FontWeight', 'bold');

output_file = fullfile(output_dir, ...
    sprintf('jsae_four_wheel_dashboard_%s.png', timestamp));
try
    exportgraphics(fig, output_file, 'Resolution', 200, ...
        'BackgroundColor', 'white');
catch
    saveas(fig, output_file);
end
fprintf('>> [OK] Dashboard: %s\n', output_file);
end