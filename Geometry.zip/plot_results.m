function plot_results(results, params)
% PLOT_RESULTS
% Menghasilkan dashboard visualisasi 5-panel untuk analisis
% pengaruh variasi Front Track Width terhadap performa kendaraan.
%
% Input:
%   results : Struct output dari calculate_dynamics()
%   params  : Struct parameter baseline dari read_vehicle_params()

T       = results.T_f;                  % Track width sweep vector [mm]
i_base  = results.baseline_idx;         % Index baseline
i_opt   = results.optimal_idx;          % Index optimal
T_base  = params.T_f;                   % Baseline track width [mm]
T_opt   = results.T_optimal;            % Optimal track width [mm]

% Warna tema
C_baseline = [0.20 0.50 0.80];     % Biru - marker baseline
C_optimal  = [0.90 0.30 0.10];     % Merah - marker optimal
C_limit    = [0.85 0.70 0.00];     % Kuning - batas peringatan
C_safe     = [0.10 0.65 0.25];     % Hijau - zona aman
C_curve    = [0.25 0.25 0.25];     % Abu gelap - kurva utama

fig = figure('Name', 'FSAE Track Width Optimization Dashboard', ...
             'NumberTitle', 'off', ...
             'Color', [0.97 0.97 0.97], ...
             'Position', [50 50 1500 920]);

% =========================================================
% GRAFIK 1: LOAD TRANSFER & CORNERING GRIP
% =========================================================
ax1 = subplot(2, 3, 1);
hold on; grid on; box on;

yyaxis left
plot(T, results.Delta_W_F, '-', 'Color', [0.2 0.4 0.8], 'LineWidth', 2, ...
     'DisplayName', '\DeltaW_F (Front)');
plot(T, results.Delta_W_R, '--', 'Color', [0.7 0.3 0.1], 'LineWidth', 2, ...
     'DisplayName', '\DeltaW_R (Rear)');
yline(0, ':', 'Color', C_limit, 'LineWidth', 1.5, 'DisplayName', 'Zero (Lift Limit)');
ylabel('Load Transfer \DeltaW [N]', 'FontWeight', 'bold');
ylim_left = ylim;

yyaxis right
plot(T, results.Fy_total, '-', 'Color', C_safe, 'LineWidth', 2.5, ...
     'DisplayName', '\SigmaF_y Total Grip');
ylabel('Total Cornering Grip \SigmaF_y [N]', 'FontWeight', 'bold', 'Color', C_safe);

% Marker baseline & optimal
yyaxis right
plot(T(i_base), results.Fy_total(i_base), 'o', 'MarkerSize', 10, ...
     'MarkerFaceColor', C_baseline, 'MarkerEdgeColor', 'k', ...
     'DisplayName', sprintf('Baseline (%.0f mm)', T_base));
plot(T(i_opt), results.Fy_total(i_opt), 's', 'MarkerSize', 10, ...
     'MarkerFaceColor', C_optimal, 'MarkerEdgeColor', 'k', ...
     'DisplayName', sprintf('Optimal (%.0f mm)', T_opt));

xline(T_base, ':', 'Color', C_baseline, 'LineWidth', 1.5, 'Alpha', 0.7);
xline(T_opt,  ':', 'Color', C_optimal,  'LineWidth', 1.5, 'Alpha', 0.7);
xlabel('Front Track Width T_f [mm]', 'FontWeight', 'bold');
title('1. Load Transfer & Cornering Grip', 'FontWeight', 'bold', 'FontSize', 11);
legend('Location', 'best', 'FontSize', 8);
set(ax1, 'FontSize', 9);

% =========================================================
% GRAFIK 2: ROLL DYNAMICS & CAMBER GAIN
% =========================================================
ax2 = subplot(2, 3, 2);
hold on; grid on; box on;

yyaxis left
plot(T, results.phi_roll, '-', 'Color', [0.2 0.4 0.8], 'LineWidth', 2, ...
     'DisplayName', '\phi_{roll} at A_y=1.7g');
yline(1.5, '--', 'Color', C_limit, 'LineWidth', 1.5, 'DisplayName', 'Roll Limit 1.5°');
plot(T(i_base), results.phi_roll(i_base), 'o', 'MarkerSize', 10, ...
     'MarkerFaceColor', C_baseline, 'MarkerEdgeColor', 'k', ...
     'DisplayName', sprintf('Baseline: %.3f°', results.phi_roll(i_base)));
plot(T(i_opt), results.phi_roll(i_opt), 's', 'MarkerSize', 10, ...
     'MarkerFaceColor', C_optimal, 'MarkerEdgeColor', 'k', ...
     'DisplayName', sprintf('Optimal: %.3f°', results.phi_roll(i_opt)));
ylabel('Body Roll Angle \phi [deg]', 'FontWeight', 'bold', 'Color', [0.2 0.4 0.8]);

yyaxis right
plot(T, results.delta_gamma_f, '-.', 'Color', [0.7 0.2 0.7], 'LineWidth', 2, ...
     'DisplayName', '\Delta\gamma_f Dynamic Camber Loss');
ylabel('Dynamic Camber Change \Delta\gamma_f [deg]', 'FontWeight', 'bold', ...
       'Color', [0.7 0.2 0.7]);

xline(T_base, ':', 'Color', C_baseline, 'LineWidth', 1.5, 'Alpha', 0.7);
xline(T_opt,  ':', 'Color', C_optimal,  'LineWidth', 1.5, 'Alpha', 0.7);
xlabel('Front Track Width T_f [mm]', 'FontWeight', 'bold');
title('2. Body Roll & Dynamic Camber', 'FontWeight', 'bold', 'FontSize', 11);
legend('Location', 'best', 'FontSize', 8);
set(ax2, 'FontSize', 9);

% =========================================================
% GRAFIK 3: ROLL STIFFNESS BREAKDOWN
% =========================================================
ax3 = subplot(2, 3, 3);
hold on; grid on; box on;

area(T, results.K_phi_total, 'FaceColor', [0.85 0.92 1.0], 'EdgeColor', 'none', ...
     'DisplayName', 'Total Roll Stiffness');
plot(T, results.K_phi_f, '-', 'Color', [0.2 0.4 0.8], 'LineWidth', 2.5, ...
     'DisplayName', 'Front Roll Stiffness K_{\phi,f}');
plot(T, results.K_phi_r, '--', 'Color', [0.7 0.3 0.1], 'LineWidth', 2, ...
     'DisplayName', 'Rear Roll Stiffness K_{\phi,r} (const)');
plot(T, results.K_phi_total, '-', 'Color', C_safe, 'LineWidth', 2.5, ...
     'DisplayName', 'Total K_{\phi,total}');
plot(T(i_base), results.K_phi_total(i_base), 'o', 'MarkerSize', 10, ...
     'MarkerFaceColor', C_baseline, 'MarkerEdgeColor', 'k', ...
     'DisplayName', sprintf('Baseline: %.1f Nm/deg', results.K_phi_total(i_base)));
plot(T(i_opt), results.K_phi_total(i_opt), 's', 'MarkerSize', 10, ...
     'MarkerFaceColor', C_optimal, 'MarkerEdgeColor', 'k', ...
     'DisplayName', sprintf('Optimal: %.1f Nm/deg', results.K_phi_total(i_opt)));

xline(T_base, ':', 'Color', C_baseline, 'LineWidth', 1.5, 'Alpha', 0.7);
xline(T_opt,  ':', 'Color', C_optimal,  'LineWidth', 1.5, 'Alpha', 0.7);
xlabel('Front Track Width T_f [mm]', 'FontWeight', 'bold');
ylabel('Roll Stiffness [Nm/deg]', 'FontWeight', 'bold');
title('3. Roll Stiffness Breakdown', 'FontWeight', 'bold', 'FontSize', 11);
legend('Location', 'best', 'FontSize', 8);
set(ax3, 'FontSize', 9);

% =========================================================
% GRAFIK 4: ACKERMANN & STEERING KICKBACK
% =========================================================
ax4 = subplot(2, 3, 4);
hold on; grid on; box on;

yyaxis left
plot(T, results.Delta_delta, '-', 'Color', [0.2 0.4 0.8], 'LineWidth', 2.5, ...
     'DisplayName', 'Ackermann \Delta\delta = \delta_i - \delta_o');
plot(T(i_base), results.Delta_delta(i_base), 'o', 'MarkerSize', 10, ...
     'MarkerFaceColor', C_baseline, 'MarkerEdgeColor', 'k', ...
     'DisplayName', sprintf('Baseline: %.3f°', results.Delta_delta(i_base)));
plot(T(i_opt), results.Delta_delta(i_opt), 's', 'MarkerSize', 10, ...
     'MarkerFaceColor', C_optimal, 'MarkerEdgeColor', 'k', ...
     'DisplayName', sprintf('Optimal: %.3f°', results.Delta_delta(i_opt)));
ylabel('Ackermann Angle Delta \Delta\delta [deg]', 'FontWeight', 'bold', ...
       'Color', [0.2 0.4 0.8]);

yyaxis right
plot(T, results.M_kickback, '-.', 'Color', [0.7 0.3 0.1], 'LineWidth', 2, ...
     'DisplayName', 'Kickback Torque M_{kickback}');
ylabel('Steering Kickback Torque [Nm]', 'FontWeight', 'bold', 'Color', [0.7 0.3 0.1]);

xline(T_base, ':', 'Color', C_baseline, 'LineWidth', 1.5, 'Alpha', 0.7);
xline(T_opt,  ':', 'Color', C_optimal,  'LineWidth', 1.5, 'Alpha', 0.7);
xlabel('Front Track Width T_f [mm]', 'FontWeight', 'bold');
title('4. Ackermann Angle & Steering Kickback', 'FontWeight', 'bold', 'FontSize', 11);
legend('Location', 'best', 'FontSize', 8);
set(ax4, 'FontSize', 9);

% =========================================================
% GRAFIK 5: STRUCTURAL SAFETY FACTOR (EULER BUCKLING)
% =========================================================
ax5 = subplot(2, 3, 5);
hold on; grid on; box on;

% Zona aman (SF >= 1.5) diarsir hijau
T_safe   = T(results.SF_lower_f >= 1.5);
SF_safe  = results.SF_lower_f(results.SF_lower_f >= 1.5);
if ~isempty(T_safe)
    fill([T_safe, fliplr(T_safe)], ...
         [ones(size(T_safe))*1.5, fliplr(SF_safe)], ...
         C_safe, 'FaceAlpha', 0.15, 'EdgeColor', 'none', ...
         'DisplayName', 'Safe Zone (SF \geq 1.5)');
end

% Zona tidak aman diarsir merah
T_unsafe = T(results.SF_lower_f < 1.5);
SF_unsafe = results.SF_lower_f(results.SF_lower_f < 1.5);
if ~isempty(T_unsafe)
    fill([T_unsafe, fliplr(T_unsafe)], ...
         [zeros(size(T_unsafe)), fliplr(SF_unsafe)], ...
         C_optimal, 'FaceAlpha', 0.15, 'EdgeColor', 'none', ...
         'DisplayName', 'Unsafe Zone (SF < 1.5)');
end

plot(T, results.SF_lower_f, '-', 'Color', C_curve, 'LineWidth', 2.5, ...
     'DisplayName', 'Buckling SF (Front Lower Arm)');
yline(1.5, '--', 'Color', C_limit, 'LineWidth', 2, ...
      'DisplayName', 'Minimum SF = 1.5');
plot(T(i_base), results.SF_lower_f(i_base), 'o', 'MarkerSize', 10, ...
     'MarkerFaceColor', C_baseline, 'MarkerEdgeColor', 'k', ...
     'DisplayName', sprintf('Baseline SF: %.1f', results.SF_lower_f(i_base)));
plot(T(i_opt), results.SF_lower_f(i_opt), 's', 'MarkerSize', 10, ...
     'MarkerFaceColor', C_optimal, 'MarkerEdgeColor', 'k', ...
     'DisplayName', sprintf('Optimal SF: %.1f', results.SF_lower_f(i_opt)));

xline(T_base, ':', 'Color', C_baseline, 'LineWidth', 1.5, 'Alpha', 0.7);
xline(T_opt,  ':', 'Color', C_optimal,  'LineWidth', 1.5, 'Alpha', 0.7);
xlabel('Front Track Width T_f [mm]', 'FontWeight', 'bold');
ylabel('Safety Factor - Euler Buckling [-]', 'FontWeight', 'bold');
title('5. Structural Safety Factor (Wishbone)', 'FontWeight', 'bold', 'FontSize', 11);
legend('Location', 'best', 'FontSize', 8);
ylim([0, min(max(results.SF_lower_f)*1.2, 50)]);
set(ax5, 'FontSize', 9);

% =========================================================
% GRAFIK 6: MAX LATERAL ACCELERATION (Ay_max) SUMMARY
% =========================================================
ax6 = subplot(2, 3, 6);
hold on; grid on; box on;

% Color gradient berdasarkan SF
SF_norm = (results.SF_lower_f - 1.5) / (max(results.SF_lower_f) - 1.5 + 0.01);
SF_norm = max(min(SF_norm, 1), 0);
for k = 1:length(T)-1
    clr = [1 - SF_norm(k), SF_norm(k)*0.7, 0.2];
    clr = max(min(clr, 1), 0);
    plot(T(k:k+1), results.Ay_max(k:k+1)*100, '-', 'Color', clr, 'LineWidth', 3);
end

plot(T(i_base), results.Ay_max(i_base)*100, 'o', 'MarkerSize', 12, ...
     'MarkerFaceColor', C_baseline, 'MarkerEdgeColor', 'k', 'LineWidth', 1.5);
text(T(i_base), results.Ay_max(i_base)*100 + 0.3, ...
     sprintf('Baseline\n%.1f%%g', results.Ay_max(i_base)*100), ...
     'FontSize', 8, 'Color', C_baseline, 'HorizontalAlignment', 'center');

plot(T(i_opt), results.Ay_max(i_opt)*100, 's', 'MarkerSize', 12, ...
     'MarkerFaceColor', C_optimal, 'MarkerEdgeColor', 'k', 'LineWidth', 1.5);
text(T(i_opt), results.Ay_max(i_opt)*100 + 0.3, ...
     sprintf('Optimal\n%.1f%%g', results.Ay_max(i_opt)*100), ...
     'FontSize', 8, 'Color', C_optimal, 'HorizontalAlignment', 'center');

yline(params.A_y * 100, '--', 'Color', [0.4 0.4 0.4], 'LineWidth', 1.5, ...
      'DisplayName', sprintf('Target A_y = %.1fg', params.A_y));

xlabel('Front Track Width T_f [mm]', 'FontWeight', 'bold');
ylabel('Max Lateral Acceleration A_{y,max} [%g]', 'FontWeight', 'bold');
title('6. Max Lateral Accel (Color = Structural Safety)', 'FontWeight', 'bold', 'FontSize', 11);
% Colorbar legenda manual
cb_ax = colorbar(ax6, 'Ticks', [0 1], 'TickLabels', {'SF < 1.5 (Unsafe)', 'SF >> 1.5 (Safe)'});
colormap(ax6, [linspace(1,0,64)', linspace(0,0.7,64)', repmat(0.2,64,1)]);
cb_ax.Label.String = 'Structural Safety';
cb_ax.FontSize = 8;
set(ax6, 'FontSize', 9);

% =========================================================
% SUPERTITLE & ANOTASI GLOBAL
% =========================================================
sgtitle(sprintf(['FSAE Vehicle Dynamics — Front Track Width Optimization\n' ...
                 'Baseline: T_f = %.0f mm  |  m = %.1f kg  |  A_y = %.1f g  |  ' ...
                 'Optimal: T_f = %.0f mm'], ...
                 T_base, params.m_total, params.A_y, T_opt), ...
        'FontSize', 13, 'FontWeight', 'bold', 'Color', [0.1 0.1 0.3]);

% =========================================================
% SIMPAN GAMBAR
% =========================================================
timestamp    = datestr(now, 'yyyymmdd_HHMMSS');
output_dir   = fileparts(which('main_trackwidth_analyzer'));
if isempty(output_dir)
    output_dir = pwd;
end
output_file  = fullfile(output_dir, sprintf('results_%s.png', timestamp));

try
    exportgraphics(fig, output_file, 'Resolution', 200, 'BackgroundColor', 'white');
    fprintf('>> [OK] Grafik disimpan: %s\n', output_file);
catch
    saveas(fig, output_file);
    fprintf('>> [OK] Grafik disimpan (saveas): %s\n', output_file);
end

end
