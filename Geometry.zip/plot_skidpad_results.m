function output_file = plot_skidpad_results(vehicle, skid, params, config, output_dir, timestamp)
% PLOT_SKIDPAD_RESULTS Create the four-wheel skidpad trade-off dashboard.

baseline_id = skid.baseline_idx;
optimal_id = skid.optimal_idx;

fig = figure('Name', 'FSAE Skidpad Four-Wheel Analysis', ...
    'NumberTitle', 'off', 'Color', 'white', ...
    'Position', [60, 60, 1500, 920]);
layout = tiledlayout(fig, 2, 3, 'TileSpacing', 'compact', ...
    'Padding', 'compact');

% ------------------------------------------------------------------
% Event geometry from Excel
% ------------------------------------------------------------------
nexttile;
hold on; grid on; box on; axis equal;
theta = linspace(0, 2 * pi, 361);
inner_radius = config.skidpad_inner_diameter_m / 2;
outer_radius = inner_radius + config.skidpad_lane_width_m;
path_radius = skid.path_radius_m;
center_offset = config.skidpad_center_distance_m / 2;
centers = [-center_offset, 0; center_offset, 0];
for circle_id = 1:2
    center_x = centers(circle_id, 1);
    plot(center_x + inner_radius * cos(theta), ...
        inner_radius * sin(theta), 'k--', 'LineWidth', 1.2, ...
        'HandleVisibility', ternary(circle_id == 1, 'on', 'off'));
    plot(center_x + outer_radius * cos(theta), ...
        outer_radius * sin(theta), 'k--', 'LineWidth', 1.2, ...
        'HandleVisibility', 'off');
    plot(center_x + path_radius * cos(theta), ...
        path_radius * sin(theta), 'LineWidth', 2, ...
        'HandleVisibility', ternary(circle_id == 1, 'on', 'off'));
end
xlabel('X [m]'); ylabel('Y [m]');
title('Skidpad Geometry from Excel');
legend('Cone boundaries', 'Vehicle path', 'Location', 'best');

% ------------------------------------------------------------------
% Timed performance
% ------------------------------------------------------------------
nexttile;
hold on; grid on; box on;
plot(vehicle.T_f, skid.lap_time_s, 'k-', 'LineWidth', 2);
plot(vehicle.T_f(baseline_id), skid.lap_time_s(baseline_id), 'o', ...
    'MarkerSize', 9, 'MarkerFaceColor', [0.15, 0.45, 0.80]);
plot(vehicle.T_f(optimal_id), skid.lap_time_s(optimal_id), 's', ...
    'MarkerSize', 9, 'MarkerFaceColor', [0.85, 0.25, 0.15]);
xlabel('Front Track Width [mm]'); ylabel('Timed Lap [s]');
title('Skidpad Track Width Trade-Off');
legend('Sweep', 'Baseline', 'Minimum Valid Time', 'Location', 'best');

% ------------------------------------------------------------------
% Speed and lateral capacity
% ------------------------------------------------------------------
nexttile;
yyaxis left
plot(vehicle.T_f, skid.speed_kph, '-', 'LineWidth', 2);
ylabel('Steady-State Speed [km/h]');
yyaxis right
plot(vehicle.T_f, skid.lateral_capacity_g, '--', 'LineWidth', 2);
ylabel('Lateral Capacity [g]');
grid on; box on; xlabel('Front Track Width [mm]');
title('Grip Benefit and Skidpad Speed');

% ------------------------------------------------------------------
% Four contact-patch loads
% ------------------------------------------------------------------
nexttile;
loads = [skid.wheel_load_N(:, baseline_id), ...
    skid.wheel_load_N(:, optimal_id)];
bar(loads);
grid on; box on;
set(gca, 'XTickLabel', {'FL', 'FR', 'RL', 'RR'});
ylabel('Normal Load [N]');
title('Four-Wheel Loads: Left Turn');
legend(sprintf('Baseline %.0f mm', vehicle.T_f(baseline_id)), ...
    sprintf('Optimal %.0f mm', vehicle.T_f(optimal_id)), ...
    'Location', 'best');

% ------------------------------------------------------------------
% Four contact-patch utilisation
% ------------------------------------------------------------------
nexttile;
utilisation = [skid.wheel_utilisation(:, baseline_id), ...
    skid.wheel_utilisation(:, optimal_id)];
bar(utilisation * 100);
yline(100, 'r--', 'Capacity');
grid on; box on;
set(gca, 'XTickLabel', {'FL', 'FR', 'RL', 'RR'});
ylabel('Lateral Tyre Utilisation [%]');
title('Four-Wheel Tyre Utilisation');
legend(sprintf('Baseline %.0f mm', vehicle.T_f(baseline_id)), ...
    sprintf('Optimal %.0f mm', vehicle.T_f(optimal_id)), ...
    'Location', 'best');

% ------------------------------------------------------------------
% Packaging, steering, and structure
% ------------------------------------------------------------------
nexttile;
hold on; grid on; box on;
yyaxis left
plot(vehicle.T_f, skid.corridor_clearance_m, '-', 'LineWidth', 2);
plot(vehicle.T_f, skid.steer_inner_deg / config.skidpad_max_steer_deg, ...
    '-.', 'LineWidth', 1.6);
yline(1, ':', 'Steer limit ratio');
ylabel('Clearance [m] / Steer Limit Ratio [-]');
yyaxis right
plot(vehicle.T_f, vehicle.SF_lower_f, '--', 'LineWidth', 2);
yline(config.minimum_buckling_sf, ':', ...
    sprintf('Minimum SF = %.2f', config.minimum_buckling_sf));
ylabel('Wishbone Buckling SF [-]');
xlabel('Front Track Width [mm]');
title('Lane, Steering, and Structural Constraints');

left_time = skid.symmetry_lap_time_s(1, baseline_id);
right_time = skid.symmetry_lap_time_s(2, baseline_id);
title(layout, sprintf(['FSAE Skidpad Four-Wheel Analysis | R = %.3f m | ' ...
    'Baseline L/R = %.3f/%.3f s | Optimal %.0f mm = %.3f s'], ...
    skid.path_radius_m, left_time, right_time, ...
    vehicle.T_f(optimal_id), skid.lap_time_s(optimal_id)), ...
    'FontWeight', 'bold');

output_file = fullfile(output_dir, ...
    sprintf('skidpad_four_wheel_dashboard_%s.png', timestamp));
try
    exportgraphics(fig, output_file, 'Resolution', 200, ...
        'BackgroundColor', 'white');
catch
    saveas(fig, output_file);
end
fprintf('>> [OK] Skidpad dashboard: %s\n', output_file);
end

function value = ternary(condition, true_value, false_value)
if condition
    value = true_value;
else
    value = false_value;
end
end
