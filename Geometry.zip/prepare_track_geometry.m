function geom = prepare_track_geometry(track, config)
% PREPARE_TRACK_GEOMETRY Turn a closed centerline into driveable quantities.
%
% The AI spline already represents a track path, so a centre line is built from
% it directly. Curvature is estimated with circumscribed circles over a moving
% window and then smoothed, because raw spline curvature inside a four wheel
% model produces unrealistically spiky corner radii.

p = track.xy_m;
n = size(p, 1);

% Arc-length parameterisation
distance_scale = config.track_declared_length_m / track.length_m;
segment_length = track.segment_length_m * distance_scale;
s = [0; cumsum(segment_length(1:end - 1))];
total_length = sum(segment_length);

% ------------------------------------------------------------------
% Curvature from circumscribed circles (closed loop, wrapping window)
% ------------------------------------------------------------------
half_win = max(1, floor(config.curvature_smoothing_points / 2));
kappa = zeros(n, 1);

for i = 1:n
    ia = mod(i - 1 - half_win, n) + 1;
    ib = i;
    ic = mod(i - 1 + half_win, n) + 1;

    a = p(ia, :);
    b = p(ib, :);
    c = p(ic, :);

    ab = b - a;
    bc = c - b;
    ca = a - c;

    cross_z = ab(1) * bc(2) - ab(2) * bc(1);
    len_ab = norm(ab);
    len_bc = norm(bc);
    len_ca = norm(ca);

    if abs(cross_z) < 1e-9 || len_ab < 1e-6 || len_bc < 1e-6 || len_ca < 1e-6
        kappa(i) = 0;
    else
        kappa(i) = 2 * cross_z / (len_ab * len_bc * len_ca);
    end
end

% Light smoothing pass to remove spline noise without destroying corners
smooth_win = max(1, round(config.curvature_smoothing_points / 3));
if smooth_win > 1
    kernel = ones(1, smooth_win) / smooth_win;
    kappa_smooth = kappa;
    for i = 1:n
        idx = mod((i - floor(smooth_win / 2) - 1):(i + ceil(smooth_win / 2) - 2), n) + 1;
        kappa_smooth(i) = mean(kappa(idx));
    end
    kappa = kappa_smooth;
end

% Signed corner radius
radius = inf(n, 1);
curved = abs(kappa) > 1e-6;
radius(curved) = 1 ./ abs(kappa(curved));

% Corner direction: +1 left turn, -1 right turn
corner_dir = sign(kappa);

% ------------------------------------------------------------------
% Forward direction tangents and normals
% ------------------------------------------------------------------
dxy = circshift(p, -1) - p;
dxy(end, :) = p(1, :) - p(end, :);
dxy_len = hypot(dxy(:, 1), dxy(:, 2));
dxy_len(dxy_len < 1e-9) = 1e-9;
tangent = dxy ./ dxy_len;

% Left-hand normal of the path
normal = [-tangent(:, 2), tangent(:, 1)];

% ------------------------------------------------------------------
% Corridor available to the car within the cone boundaries
% ------------------------------------------------------------------
available_half_width = config.track_width_m / 2 - config.cone_safety_margin_m;

geom.xy_m = p;
geom.distance_m = s;
geom.segment_length_m = segment_length;
geom.length_m = total_length;
geom.raw_spline_length_m = track.length_m;
geom.distance_scale = distance_scale;
geom.kappa = kappa;
geom.radius_m = radius;
geom.corner_dir = corner_dir;
geom.tangent = tangent;
geom.normal = normal;
geom.available_half_width_m = available_half_width;
end
