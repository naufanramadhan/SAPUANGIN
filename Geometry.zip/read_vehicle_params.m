function params = read_vehicle_params(excel_path)
% READ_VEHICLE_PARAMS
% Membaca parameter baseline kendaraan dari file Excel FSAE_VD_3_KASAR .xlsx
% secara real-time sehingga setiap perubahan di Excel langsung terbaca.
%
% Input:
%   excel_path : Path lengkap ke file Excel (string)
% Output:
%   params     : Struct berisi semua parameter baseline kendaraan
%
% Mapping Cell (Sheet: 02_INPUT_VARIABLES, Kolom E = Baseline Value):
%   Baris 4  (E4)  = g          (gravitational acceleration)
%   Baris 5  (E5)  = m_total    (total vehicle mass)
%   Baris 6  (E6)  = WD_f       (front weight distribution fraction)
%   ...dst

fprintf('----------------------------------------\n');
fprintf('Reading parameters from Excel...\n');
fprintf('File: %s\n', excel_path);

% --- Baca sheet 02_INPUT_VARIABLES ---
sheet_input = '02_INPUT_VARIABLES';
try
    raw = readcell(excel_path, 'Sheet', sheet_input, ...
                   'Range', 'E4:E58', 'UseExcel', false);
catch
    error('[ERROR] Gagal membaca file Excel. Pastikan file tidak sedang terbuka di Excel lain.');
end

% Helper: ambil nilai numerik dari cell array, return NaN jika kosong/teks
    function v = getval(raw_data, row_offset)
        val = raw_data{row_offset, 1};
        if isnumeric(val)
            v = val;
        elseif ismissing(val) || isempty(val)
            v = NaN;
        else
            v = NaN;
            warning('Nilai di baris %d bukan numerik: %s', row_offset+3, mat2str(val));
        end
    end

% =========================================================
% SECTION 1: ENVIRONMENT & VEHICLE MASS (Baris 4-8 -> offset 1-5)
% =========================================================
params.g        = getval(raw, 1);   % E4  - Gravitational Acceleration [m/s^2]
params.m_total  = getval(raw, 2);   % E5  - Total Vehicle Mass [kg]
params.WD_f     = getval(raw, 3);   % E6  - Front Weight Distribution [-]
params.m_uf     = getval(raw, 4);   % E7  - Front Unsprung Mass [kg]
params.m_ur     = getval(raw, 5);   % E8  - Rear Unsprung Mass [kg]

% =========================================================
% SECTION 2: TRACK GEOMETRY & WHEELBASE (Baris 9-11 -> offset 6-8)
% =========================================================
params.T_f      = getval(raw, 6);   % E9  - Front Track Width [mm]
params.T_r      = getval(raw, 7);   % E10 - Rear Track Width [mm]
params.L        = getval(raw, 8);   % E11 - Wheelbase [mm]

% =========================================================
% SECTION 3: CG GEOMETRY (Baris 12-14 -> offset 9-11)
% =========================================================
params.h        = getval(raw, 9);   % E12 - Total CG Height [mm]
params.h_uf     = getval(raw, 10);  % E13 - Front Unsprung CG Height [mm]
params.h_ur     = getval(raw, 11);  % E14 - Rear Unsprung CG Height [mm]

% =========================================================
% SECTION 4: ROLL CENTER HEIGHT (Baris 15-16 -> offset 12-13)
% =========================================================
params.z_RF     = getval(raw, 12);  % E15 - Front Roll Center Height [mm]
params.z_RR     = getval(raw, 13);  % E16 - Rear Roll Center Height [mm]

% =========================================================
% SECTION 5: FRONT WISHBONE GEOMETRY (Baris 17-20 -> offset 14-17)
% =========================================================
params.L_lower_f    = getval(raw, 14);  % E17 - Front Lower Wishbone Length [mm]
params.L_upper_f    = getval(raw, 15);  % E18 - Front Upper Wishbone Length [mm]
params.Ratio_UL_f   = getval(raw, 16);  % E19 - Front Upper-to-Lower Ratio [-]
params.W_inboard_lf = getval(raw, 17);  % E20 - Front Inboard Lower Pivot Width [mm]

% =========================================================
% SECTION 6: FRONT ALIGNMENT (Baris 21-26 -> offset 18-23)
% =========================================================
params.gamma_0f     = getval(raw, 18);  % E21 - Front Static Camber [deg]
params.theta_KPI_f  = getval(raw, 19);  % E22 - Front KPI Angle [deg]
params.theta_caster = getval(raw, 20);  % E23 - Front Caster Angle [deg]
params.d_KPI_f      = getval(raw, 21);  % E24 - Front Kingpin Offset [mm]
params.W_offset_f   = getval(raw, 22);  % E25 - Front Wheel Rim Offset [mm]
params.R_scrub_f    = getval(raw, 23);  % E26 - Front Scrub Radius [mm]

% =========================================================
% SECTION 7: REAR WISHBONE GEOMETRY (Baris 27-30 -> offset 24-27)
% =========================================================
params.L_lower_r    = getval(raw, 24);  % E27 - Rear Lower Wishbone Length [mm]
params.L_upper_r    = getval(raw, 25);  % E28 - Rear Upper Wishbone Length [mm]
params.Ratio_UL_r   = getval(raw, 26);  % E29 - Rear Upper-to-Lower Ratio [-]
params.W_inboard_lr = getval(raw, 27);  % E30 - Rear Inboard Lower Pivot Width [mm]

% =========================================================
% SECTION 8: REAR ALIGNMENT (Baris 31-33 -> offset 28-30)
% =========================================================
params.gamma_0r     = getval(raw, 28);  % E31 - Rear Static Camber [deg]
params.Toe_r        = getval(raw, 29);  % E32 - Rear Static Toe [deg]
params.W_offset_r   = getval(raw, 30);  % E33 - Rear Wheel Rim Offset [mm]

% =========================================================
% SECTION 9: REAR DRIVETRAIN (Baris 34-35 -> offset 31-32)
% =========================================================
params.L_halfshaft  = getval(raw, 31);  % E34 - Rear Half-Shaft Length [mm]
params.theta_CV_max = getval(raw, 32);  % E35 - CV Joint Max Angle [deg]

% =========================================================
% SECTION 10: STEERING (Baris 36 -> offset 33)
% =========================================================
params.R_corner     = getval(raw, 33);  % E36 - Reference Corner Radius [m]

% =========================================================
% SECTION 11: FRONT ELASTIC (Baris 37-39 -> offset 34-36)
% =========================================================
params.K_sf         = getval(raw, 34);  % E37 - Front Spring Rate [N/mm]
params.IR_f         = getval(raw, 35);  % E38 - Front Motion Ratio [-]
params.K_arbf       = getval(raw, 36);  % E39 - Front ARB Stiffness [Nm/deg]

% =========================================================
% SECTION 12: REAR ELASTIC (Baris 40-42 -> offset 37-39)
% =========================================================
params.K_sr         = getval(raw, 37);  % E40 - Rear Spring Rate [N/mm]
params.IR_r         = getval(raw, 38);  % E41 - Rear Motion Ratio [-]
params.K_arbr       = getval(raw, 39);  % E42 - Rear ARB Stiffness [Nm/deg]

% =========================================================
% SECTION 13: FRONT TIRE TTC (Baris 43-47 -> offset 40-44)
% =========================================================
params.r_f          = getval(raw, 40);  % E43 - Front Tire Unloaded Radius [mm]
params.K_tf         = getval(raw, 41);  % E44 - Front Tire Vertical Stiffness [N/mm]
params.mu_0f        = getval(raw, 42);  % E45 - Front Peak Friction Coeff [-]
params.dmu_dFz_f    = getval(raw, 43);  % E46 - Front Tire Load Sensitivity [1/N]
params.F_z0f        = getval(raw, 44);  % E47 - Front Reference Nominal Load [N]

% =========================================================
% SECTION 14: REAR TIRE TTC (Baris 48-52 -> offset 45-49)
% =========================================================
params.r_r          = getval(raw, 45);  % E48 - Rear Tire Unloaded Radius [mm]
params.K_tr         = getval(raw, 46);  % E49 - Rear Tire Vertical Stiffness [N/mm]
params.mu_0r        = getval(raw, 47);  % E50 - Rear Peak Friction Coeff [-]
params.dmu_dFz_r    = getval(raw, 48);  % E51 - Rear Tire Load Sensitivity [1/N]
params.F_z0r        = getval(raw, 49);  % E52 - Rear Reference Nominal Load [N]

% =========================================================
% SECTION 15: WISHBONE STRUCTURE (Baris 53-56 -> offset 50-53)
% =========================================================
params.OD           = getval(raw, 50);  % E53 - Tube OD [mm]
params.t_wall       = getval(raw, 51);  % E54 - Tube Wall Thickness [mm]
params.E_modulus    = getval(raw, 52);  % E55 - Elastic Modulus [MPa]
params.Sigma_y      = getval(raw, 53);  % E56 - Yield Strength [MPa]

% =========================================================
% SECTION 16: UPRIGHT + SIMULATION TARGET (Baris 57-58 -> offset 54-55)
% =========================================================
params.L_stub       = getval(raw, 54);  % E57 - Stub Axle Overhang [mm]
params.A_y          = getval(raw, 55);  % E58 - Target Lateral Acceleration [g]

% =========================================================
% DERIVED / COMPUTED CONSTANTS (tidak di-sweep)
% =========================================================
params.W_total  = params.m_total * params.g;                        % Total Weight [N]
params.m_s      = params.m_total - params.m_uf - params.m_ur;       % Sprung Mass [kg]
params.h_s      = ((params.m_total * params.h) - ...
                   (params.m_uf * params.h_uf) - ...
                   (params.m_ur * params.h_ur)) / params.m_s;       % Sprung CG Height [mm]

% Tube cross-section properties
params.ID       = params.OD - 2 * params.t_wall;
params.A_tube   = pi/4 * (params.OD^2 - params.ID^2);              % [mm^2]
params.I_tube   = pi/64 * (params.OD^4 - params.ID^4);             % [mm^4]

% Validasi parameter kritis
assert(~isnan(params.m_total), 'ERROR: m_total tidak terbaca dari Excel!');
assert(~isnan(params.T_f),     'ERROR: T_f tidak terbaca dari Excel!');
assert(~isnan(params.A_y),     'ERROR: A_y tidak terbaca dari Excel!');
assert(params.m_total > 0,     'ERROR: m_total harus positif!');
assert(params.T_f > 0,         'ERROR: T_f harus positif!');

fprintf('  >> m_total     = %.1f kg\n',  params.m_total);
fprintf('  >> T_f_base    = %.1f mm\n',  params.T_f);
fprintf('  >> T_r_base    = %.1f mm\n',  params.T_r);
fprintf('  >> h_CG        = %.1f mm\n',  params.h);
fprintf('  >> h_s (calc)  = %.2f mm\n',  params.h_s);
fprintf('  >> A_y target  = %.2f g\n',   params.A_y);
fprintf('  >> K_sf        = %.1f N/mm\n',params.K_sf);
fprintf('  >> mu_0f       = %.3f\n',     params.mu_0f);
fprintf('>> [OK] %d parameter berhasil dimuat dari Excel.\n', 32);
fprintf('----------------------------------------\n');

end
