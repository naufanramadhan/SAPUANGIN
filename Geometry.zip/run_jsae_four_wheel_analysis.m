function run_jsae_four_wheel_analysis(script_dir)
% RUN_JSAE_FOUR_WHEEL_ANALYSIS Execute the Excel-driven JSAE workflow.

input_dir = fullfile(script_dir, 'input');
output_dir = fullfile(script_dir, 'output');
excel_file = fullfile(input_dir, 'FSAE_VD_3_KASAR .xlsx');
track_file = fullfile(input_dir, 'track', 'fast_lane.ai');

assert(isfile(excel_file), 'Workbook input tidak ditemukan: %s', excel_file);
assert(isfile(track_file), 'Track AI tidak ditemukan: %s', track_file);
if ~isfolder(output_dir)
    mkdir(output_dir);
end

addpath(script_dir);
addpath(input_dir);

fprintf('\n============================================================\n');
fprintf(' FSAE JAPAN FOUR-WHEEL TRACK WIDTH ANALYZER\n');
fprintf(' Workbook: %s\n', excel_file);
fprintf('============================================================\n');

fprintf('\n[1/6] Membaca seluruh input dari Excel...\n');
params = read_vehicle_params(excel_file);
config = simulation_config(excel_file);
T_sweep = config.front_track_min_mm:config.track_step_mm:...
    config.front_track_max_mm;

fprintf('\n[2/6] Membaca dan menyiapkan racing line JSAE...\n');
track = read_ac_ai_spline(track_file);
geom = prepare_track_geometry(track, config);
fprintf('>> [OK] %d titik | raw %.2f m | simulation %.2f m\n', ...
    track.point_count, geom.raw_spline_length_m, geom.length_m);

fprintf('\n[3/6] Menghitung empat contact patch untuk %d kandidat...\n', ...
    numel(T_sweep));
vehicle = calculate_four_wheel(params, T_sweep, config);

fprintf('\n[4/6] Menjalankan closed-loop JSAE speed profile...\n');
lap = simulate_jsae_lap(geom, vehicle, params, config);
baseline_id = lap.baseline_idx;
optimal_id = lap.optimal_idx;

fprintf('\n[5/6] Menjalankan four-wheel skidpad simulation...\n');
skidpad = simulate_skidpad(vehicle, params, config);
skidpad_optimal_id = skidpad.optimal_idx;

fprintf('\n============================================================\n');
fprintf(' RINGKASAN HASIL\n');
fprintf('============================================================\n');
fprintf('%-32s %12s %12s %12s\n', ...
    'Parameter', 'Baseline', 'Optimal', 'Delta');
fprintf('%s\n', repmat('-', 1, 72));
print_row('Front track width', ' mm', vehicle.T_f(baseline_id), ...
    vehicle.T_f(optimal_id));
print_row('Rear track width', ' mm', vehicle.T_r(baseline_id), ...
    vehicle.T_r(optimal_id));
print_row('Lateral capacity', ' g', vehicle.Ay_capacity(baseline_id), ...
    vehicle.Ay_capacity(optimal_id));
print_row('Yaw inertia estimate', ' kgm2', lap.yaw_inertia_kgm2(baseline_id), ...
    lap.yaw_inertia_kgm2(optimal_id));
print_row('Corridor per side', ' m', lap.corridor_clearance_m(baseline_id), ...
    lap.corridor_clearance_m(optimal_id));
print_row('Estimated lap time', ' s', lap.lap_time_s(baseline_id), ...
    lap.lap_time_s(optimal_id));
print_row('Average speed', ' km/h', lap.average_speed_kph(baseline_id), ...
    lap.average_speed_kph(optimal_id));
print_row('Minimum wheel load', ' N', lap.minimum_wheel_load_N(baseline_id), ...
    lap.minimum_wheel_load_N(optimal_id));
print_row('Wishbone buckling SF', ' -', vehicle.SF_lower_f(baseline_id), ...
    vehicle.SF_lower_f(optimal_id));
fprintf('%s\n', repmat('-', 1, 72));
fprintf('REKOMENDASI: T_f = %.0f mm, T_r = %.0f mm\n', ...
    vehicle.T_f(optimal_id), vehicle.T_r(optimal_id));
fprintf('Perubahan waktu lap terhadap baseline: %+.3f s (%+.3f%%)\n', ...
    lap.lap_time_s(optimal_id) - lap.lap_time_s(baseline_id), ...
    (lap.lap_time_s(optimal_id) / lap.lap_time_s(baseline_id) - 1) * 100);
if lap.minimum_wheel_load_N(baseline_id) <= 0
    fprintf(['WARNING: target A_y Excel menyebabkan wheel lift pada evaluasi ' ...
        'baseline statis.\n']);
end

fprintf('\n------------------------------------------------------------\n');
fprintf(' RINGKASAN SKIDPAD\n');
fprintf('------------------------------------------------------------\n');
print_row('Front track width', ' mm', vehicle.T_f(baseline_id), ...
    vehicle.T_f(skidpad_optimal_id));
print_row('Path radius', ' m', skidpad.path_radius_m, ...
    skidpad.path_radius_m);
print_row('Corridor per side', ' m', ...
    skidpad.corridor_clearance_m(baseline_id), ...
    skidpad.corridor_clearance_m(skidpad_optimal_id));
print_row('Steady-state speed', ' km/h', skidpad.speed_kph(baseline_id), ...
    skidpad.speed_kph(skidpad_optimal_id));
print_row('Timed lap left', ' s', ...
    skidpad.symmetry_lap_time_s(1, baseline_id), ...
    skidpad.symmetry_lap_time_s(1, skidpad_optimal_id));
print_row('Timed lap right', ' s', ...
    skidpad.symmetry_lap_time_s(2, baseline_id), ...
    skidpad.symmetry_lap_time_s(2, skidpad_optimal_id));
print_row('Combined timed laps', ' s', skidpad.total_time_s(baseline_id), ...
    skidpad.total_time_s(skidpad_optimal_id));
print_row('Minimum wheel load', ' N', ...
    skidpad.minimum_wheel_load_N(baseline_id), ...
    skidpad.minimum_wheel_load_N(skidpad_optimal_id));
fprintf('REKOMENDASI SKIDPAD: T_f = %.0f mm, T_r = %.0f mm\n', ...
    vehicle.T_f(skidpad_optimal_id), vehicle.T_r(skidpad_optimal_id));
fprintf('Perubahan waktu per lap terhadap baseline: %+.3f s (%+.3f%%)\n', ...
    skidpad.lap_time_s(skidpad_optimal_id) - ...
    skidpad.lap_time_s(baseline_id), ...
    (skidpad.lap_time_s(skidpad_optimal_id) / ...
    skidpad.lap_time_s(baseline_id) - 1) * 100);

fprintf('\n[6/6] Menyimpan hasil endurance dan skidpad...\n');
timestamp = datestr(now, 'yyyymmdd_HHMMSS');
csv_file = fullfile(output_dir, sprintf('track_width_summary_%s.csv', timestamp));
skidpad_csv_file = fullfile(output_dir, ...
    sprintf('skidpad_track_width_summary_%s.csv', timestamp));
mat_file = fullfile(output_dir, sprintf('jsae_four_wheel_results_%s.mat', timestamp));
writetable(lap.summary, csv_file);
writetable(skidpad.summary, skidpad_csv_file);
save(mat_file, 'params', 'config', 'track', 'geom', 'vehicle', 'lap', ...
    'skidpad');
dashboard_file = plot_jsae_results(geom, vehicle, lap, params, config, ...
    output_dir, timestamp);
skidpad_dashboard_file = plot_skidpad_results(vehicle, skidpad, params, ...
    config, output_dir, timestamp);

fprintf('>> [OK] Endurance CSV: %s\n', csv_file);
fprintf('>> [OK] Skidpad CSV: %s\n', skidpad_csv_file);
fprintf('>> [OK] MAT: %s\n', mat_file);
fprintf('>> [OK] Endurance PNG: %s\n', dashboard_file);
fprintf('>> [OK] Skidpad PNG: %s\n', skidpad_dashboard_file);
fprintf('\nSELESAI. Ubah workbook di folder input, save, lalu run ulang.\n');
end

function print_row(label, unit, baseline, optimal)
fprintf('%-32s %10.3f%s %10.3f%s %+10.3f%s\n', ...
    label, baseline, unit, optimal, unit, optimal - baseline, unit);
end