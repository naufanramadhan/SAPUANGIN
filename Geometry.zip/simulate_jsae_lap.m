function lap = simulate_jsae_lap(geom, vehicle, params, config)
% SIMULATE_JSAE_LAP Quasi-steady closed-loop simulation using four tyres.

point_count = size(geom.xy_m, 1);
case_count = numel(vehicle.T_f);
g = params.g;
mm_per_m = 1000;

lap.vehicle_width_m = zeros(1, case_count);
lap.corridor_clearance_m = zeros(1, case_count);
lap.yaw_inertia_kgm2 = zeros(1, case_count);
lap.lap_time_s = inf(1, case_count);
lap.max_speed_kph = zeros(1, case_count);
lap.average_speed_kph = zeros(1, case_count);
lap.max_yaw_rate_degps = zeros(1, case_count);
lap.max_tire_utilisation = zeros(1, case_count);
lap.minimum_wheel_load_N = zeros(1, case_count);
lap.speed_mps = zeros(point_count, case_count);
lap.Ay_g = zeros(point_count, case_count);
lap.tire_utilisation = zeros(4, point_count, case_count);
lap.wheel_load_N = zeros(4, point_count, case_count);

W_total = params.W_total;
W_f_wheel = W_total * params.WD_f / 2;
W_r_wheel = W_total * (1 - params.WD_f) / 2;
z_RA = params.z_RF + (params.z_RR - params.z_RF) * ...
    (1 - params.WD_f);
M_R_per_g = params.m_s * g * ((params.h_s - z_RA) / mm_per_m);

grip = @(mu_0, dmu, F_z0, Fz) ...
    max(mu_0 + dmu .* (max(Fz, 0) - F_z0), 0) .* max(Fz, 0);

for case_id = 1:case_count
    Tf = vehicle.T_f(case_id);
    Tr = vehicle.T_r(case_id);
    vehicle_width = (max(Tf, Tr) + config.tire_section_width_mm) / ...
        mm_per_m;
    corridor_clearance = geom.available_half_width_m - vehicle_width / 2;

    lap.vehicle_width_m(case_id) = vehicle_width;
    lap.corridor_clearance_m(case_id) = corridor_clearance;
    if corridor_clearance <= 0
        continue;
    end

    effective_kappa = abs(geom.kappa) ./ ...
        (1 + abs(geom.kappa) * corridor_clearance);
    lateral_limit = sqrt(config.cornering_safety_factor * ...
        vehicle.Ay_capacity(case_id) * g ./ max(effective_kappa, eps));
    speed_limit = min(lateral_limit, config.max_speed_kph / 3.6);
    speed = solve_speed_profile(speed_limit, effective_kappa, ...
        vehicle.Ay_capacity(case_id) * g);

    next_speed = circshift(speed, -1);
    segment_time = 2 * geom.segment_length_m ./ ...
        max(speed + next_speed, eps);
    Ay_mps2 = speed.^2 .* effective_kappa;
    Ay_g = Ay_mps2 / g;

    lap.speed_mps(:, case_id) = speed;
    lap.Ay_g(:, case_id) = Ay_g;
    lap.lap_time_s(case_id) = sum(segment_time);
    lap.max_speed_kph(case_id) = max(speed) * 3.6;
    lap.average_speed_kph(case_id) = geom.length_m / ...
        lap.lap_time_s(case_id) * 3.6;
    lap.max_yaw_rate_degps(case_id) = max(speed .* effective_kappa) * ...
        180 / pi;

    [wheel_load, utilisation] = four_wheel_state(Ay_g, ...
        geom.corner_dir, case_id);
    lap.wheel_load_N(:, :, case_id) = wheel_load;
    lap.tire_utilisation(:, :, case_id) = utilisation;
    lap.max_tire_utilisation(case_id) = max(utilisation, [], 'all');
    lap.minimum_wheel_load_N(case_id) = min(wheel_load, [], 'all');

    wheelbase = params.L / mm_per_m;
    front_x = wheelbase * (1 - params.WD_f);
    rear_x = wheelbase * params.WD_f;
    front_mass = params.m_total * params.WD_f / 2;
    rear_mass = params.m_total * (1 - params.WD_f) / 2;
    lap.yaw_inertia_kgm2(case_id) = config.yaw_inertia_mass_factor * (...
        2 * front_mass * (front_x^2 + (Tf / (2 * mm_per_m))^2) + ...
        2 * rear_mass * (rear_x^2 + (Tr / (2 * mm_per_m))^2));
end

lap.baseline_idx = vehicle.baseline_idx;
lap.valid_mask = lap.corridor_clearance_m > 0 & ...
    vehicle.SF_lower_f >= config.minimum_buckling_sf & ...
    vehicle.cv_angle_deg <= params.theta_CV_max;

valid_time = lap.lap_time_s;
valid_time(~lap.valid_mask) = inf;
[lap.optimal_lap_time_s, lap.optimal_idx] = min(valid_time);
if isinf(lap.optimal_lap_time_s)
    error(['Tidak ada track width yang memenuhi corridor, buckling SF, ' ...
        'dan batas sudut CV dari Excel.']);
end
lap.T_optimal_mm = vehicle.T_f(lap.optimal_idx);

lap.summary = table(vehicle.T_f(:), vehicle.T_r(:), ...
    lap.vehicle_width_m(:), lap.corridor_clearance_m(:), ...
    vehicle.Ay_capacity(:), lap.yaw_inertia_kgm2(:), ...
    lap.lap_time_s(:), lap.average_speed_kph(:), ...
    lap.max_speed_kph(:), lap.max_yaw_rate_degps(:), ...
    lap.max_tire_utilisation(:), lap.minimum_wheel_load_N(:), ...
    vehicle.SF_lower_f(:), vehicle.cv_angle_deg(:), lap.valid_mask(:), ...
    'VariableNames', {'FrontTrack_mm', 'RearTrack_mm', ...
    'VehicleWidth_m', 'CorridorClearance_m', 'LateralCapacity_g', ...
    'YawInertia_kgm2', 'LapTime_s', 'AverageSpeed_kph', ...
    'MaxSpeed_kph', 'MaxYawRate_degps', 'MaxTireUtilisation', ...
    'MinimumWheelLoad_N', 'BucklingSF', 'CVAngle_deg', 'Valid'});

    function speed = solve_speed_profile(speed_limit, kappa, Ay_limit)
        speed = speed_limit;
        for iteration = 1:round(config.speed_profile_iterations)
            for point_id = 1:point_count
                next_id = mod(point_id, point_count) + 1;
                lateral_ratio = min(speed(point_id)^2 * kappa(point_id) / ...
                    max(Ay_limit, eps), 1);
                accel = config.max_accel_mps2 * ...
                    sqrt(max(1 - lateral_ratio^2, 0));
                reachable = sqrt(speed(point_id)^2 + ...
                    2 * accel * geom.segment_length_m(point_id));
                speed(next_id) = min([speed(next_id), ...
                    speed_limit(next_id), reachable]);
            end

            for point_id = point_count:-1:1
                previous_id = mod(point_id - 2, point_count) + 1;
                lateral_ratio = min(speed(point_id)^2 * kappa(point_id) / ...
                    max(Ay_limit, eps), 1);
                braking = config.max_brake_mps2 * ...
                    sqrt(max(1 - lateral_ratio^2, 0));
                reachable = sqrt(speed(point_id)^2 + ...
                    2 * braking * geom.segment_length_m(previous_id));
                speed(previous_id) = min([speed(previous_id), ...
                    speed_limit(previous_id), reachable]);
            end
        end
    end

    function [Fz, utilisation] = four_wheel_state(Ay, direction, case_id)
        Kf = vehicle.K_phi_f(case_id);
        Kr = vehicle.K_phi_r(case_id);
        Ktotal = vehicle.K_phi_total(case_id);
        Tf = vehicle.T_f(case_id);
        Tr = vehicle.T_r(case_id);

        dWf = Ay * params.m_uf * g * (params.h_uf / Tf) + ...
            Ay * params.m_s * g * params.WD_f * (params.z_RF / Tf) + ...
            (Kf / Ktotal) * M_R_per_g .* Ay / (Tf / mm_per_m);
        dWr = Ay * params.m_ur * g * (params.h_ur / Tr) + ...
            Ay * params.m_s * g * (1 - params.WD_f) * ...
            (params.z_RR / Tr) + ...
            (Kr / Ktotal) * M_R_per_g .* Ay / (Tr / mm_per_m);

        signed_front = direction .* dWf;
        signed_rear = direction .* dWr;
        Fz = [W_f_wheel - signed_front.'; W_f_wheel + signed_front.'; ...
            W_r_wheel - signed_rear.'; W_r_wheel + signed_rear.'];

        capacity = [
            grip(params.mu_0f, params.dmu_dFz_f, params.F_z0f, Fz(1, :));
            grip(params.mu_0f, params.dmu_dFz_f, params.F_z0f, Fz(2, :));
            grip(params.mu_0r, params.dmu_dFz_r, params.F_z0r, Fz(3, :));
            grip(params.mu_0r, params.dmu_dFz_r, params.F_z0r, Fz(4, :))];

        required_total = params.m_total * (Ay * g).';
        required_front = params.WD_f * required_total;
        required_rear = (1 - params.WD_f) * required_total;
        front_capacity = max(sum(capacity(1:2, :), 1), eps);
        rear_capacity = max(sum(capacity(3:4, :), 1), eps);
        required = [
            required_front .* capacity(1, :) ./ front_capacity;
            required_front .* capacity(2, :) ./ front_capacity;
            required_rear .* capacity(3, :) ./ rear_capacity;
            required_rear .* capacity(4, :) ./ rear_capacity];
        utilisation = required ./ max(capacity, eps);
    end
end