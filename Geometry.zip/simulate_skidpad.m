function skid = simulate_skidpad(vehicle, params, config)
% SIMULATE_SKIDPAD Four-wheel steady-state evaluation of the skidpad event.
%
% Geometry follows the Formula SAE skidpad: two circles of equal radius with
% two timed laps, driven once to the left and once to the right. The car load
% state reuses the same four contact patches, roll stiffness distribution, and
% nonlinear tyre model as the endurance simulation, so both events are
% comparable. All dimensions are read from the Excel configuration sheet.

g = params.g;
mm_per_m = 1000;
case_count = numel(vehicle.T_f);

% Path radius follows the middle of the drivable lane between the circles
path_radius_m = config.skidpad_inner_diameter_m / 2 + ...
    config.skidpad_lane_width_m / 2;

% Direction signs: +1 left turn, -1 right turn
directions = [1, -1];
direction_names = {'Left', 'Right'};

skid.path_radius_m = path_radius_m;
skid.timed_laps_per_direction = config.skidpad_timed_laps_per_direction;
skid.max_steer_deg = config.skidpad_max_steer_deg;

skid.vehicle_width_m = zeros(1, case_count);
skid.corridor_clearance_m = zeros(1, case_count);
skid.lateral_capacity_g = zeros(1, case_count);
skid.direction = cell(1, case_count);

skid.speed_kph = zeros(1, case_count);
skid.lap_time_s = zeros(1, case_count);
skid.total_time_s = zeros(1, case_count);
skid.steer_outer_deg = zeros(1, case_count);
skid.steer_inner_deg = zeros(1, case_count);
skid.ackermann_delta_deg = zeros(1, case_count);
skid.steer_limit_kph = zeros(1, case_count);
skid.steer_limited = false(1, case_count);
skid.max_tire_utilisation = zeros(1, case_count);
skid.wheel_utilisation = zeros(4, case_count);
skid.wheel_load_N = zeros(4, case_count);
skid.minimum_wheel_load_N = zeros(1, case_count);

for case_id = 1:case_count
    Tf = vehicle.T_f(case_id);
    Tr = vehicle.T_r(case_id);

    vehicle_width = (max(Tf, Tr) + config.tire_section_width_mm) / mm_per_m;
    corridor_clearance = config.skidpad_lane_width_m / 2 - ...
        vehicle_width / 2;

    skid.vehicle_width_m(case_id) = vehicle_width;
    skid.corridor_clearance_m(case_id) = corridor_clearance;
    skid.lateral_capacity_g(case_id) = vehicle.Ay_capacity(case_id);

    if case_id == vehicle.baseline_idx
        skid.direction{case_id} = 'Baseline';
    else
        skid.direction{case_id} = 'Both';
    end

    if corridor_clearance <= 0
        skid.lap_time_s(case_id) = inf;
        skid.total_time_s(case_id) = inf;
        continue;
    end

    % Steady-state cornering speed limited by available lateral grip
    v_corner_mps = sqrt(config.cornering_safety_factor * ...
        vehicle.Ay_capacity(case_id) * g * path_radius_m);
    v_corner_kph = v_corner_mps * 3.6;

    speed_kph = min(v_corner_kph, config.max_speed_kph);

    % Steering geometry limits cornering speed as well
    steer_limit_kph = steer_speed_limit(Tf, Tr, speed_kph);
    if steer_limit_kph < speed_kph
        speed_kph = steer_limit_kph;
        skid.steer_limited(case_id) = true;
    end

    speed_mps = max(speed_kph / 3.6, eps);
    lap_time_s = (2 * pi * path_radius_m) / speed_mps;

    skid.speed_kph(case_id) = speed_kph;
    skid.steer_limit_kph(case_id) = steer_limit_kph;
    skid.lap_time_s(case_id) = lap_time_s;
    skid.total_time_s(case_id) = 2 * config.skidpad_timed_laps_per_direction * ...
        lap_time_s;

    Ay_g = speed_mps^2 / (path_radius_m * g);
    skid.steer_outer_deg(case_id) = atan2d(params.L, ...
        (path_radius_m + Tr / (2 * mm_per_m)) * mm_per_m);
    skid.steer_inner_deg(case_id) = atan2d(params.L, ...
        (path_radius_m - Tf / (2 * mm_per_m)) * mm_per_m);
    skid.ackermann_delta_deg(case_id) = skid.steer_inner_deg(case_id) - ...
        skid.steer_outer_deg(case_id);

    % Utilisation is reported for the loading that matters most: the outer
    % wheels. A left-hand skidpad lap turns to the left, so the right side is
    % the outside of the corner and carries the extra vertical load.
    [wheel_load, wheel_utilisation] = four_wheel_state(Ay_g, directions(1), ...
        case_id);
    skid.wheel_load_N(:, case_id) = wheel_load;
    skid.wheel_utilisation(:, case_id) = wheel_utilisation;
    skid.max_tire_utilisation(case_id) = max(wheel_utilisation);
    skid.minimum_wheel_load_N(case_id) = min(wheel_load);
end

% Both directions are symmetric for a symmetric setup, so the reported lap
% time applies to each direction. This loop documents the symmetry explicitly
% and would expose any future asymmetry in the setup.
skid.symmetry_lap_time_s = zeros(numel(directions), case_count);
for dir_id = 1:numel(directions)
    skid.symmetry_lap_time_s(dir_id, :) = skid.lap_time_s;
end
skid.direction_names = direction_names;

skid.baseline_idx = vehicle.baseline_idx;
skid.valid_mask = skid.corridor_clearance_m > 0 & ...
    ~isinf(skid.total_time_s) & ...
    vehicle.SF_lower_f >= config.minimum_buckling_sf & ...
    vehicle.cv_angle_deg <= params.theta_CV_max;

valid_time = skid.total_time_s;
valid_time(~skid.valid_mask) = inf;
[skid.optimal_total_time_s, skid.optimal_idx] = min(valid_time);
if isinf(skid.optimal_total_time_s)
    error(['Tidak ada track width yang memenuhi corridor, buckling SF, ' ...
        'dan batas sudut CV pada event skidpad.']);
end
skid.T_optimal_mm = vehicle.T_f(skid.optimal_idx);

skid.summary = table(vehicle.T_f(:), vehicle.T_r(:), ...
    skid.vehicle_width_m(:), skid.corridor_clearance_m(:), ...
    skid.lateral_capacity_g(:), skid.speed_kph(:), skid.lap_time_s(:), ...
    skid.total_time_s(:), skid.max_tire_utilisation(:), ...
    skid.minimum_wheel_load_N(:), skid.steer_inner_deg(:), ...
    skid.steer_outer_deg(:), skid.ackermann_delta_deg(:), ...
    skid.steer_limited(:), vehicle.SF_lower_f(:), vehicle.cv_angle_deg(:), ...
    skid.valid_mask(:), 'VariableNames', {'FrontTrack_mm', 'RearTrack_mm', ...
    'VehicleWidth_m', 'CorridorClearance_m', 'LateralCapacity_g', ...
    'Speed_kph', 'LapTime_s', 'TotalTime_s', 'MaxTireUtilisation', ...
    'MinimumWheelLoad_N', 'SteerInner_deg', 'SteerOuter_deg', ...
    'AckermannDelta_deg', 'SteerLimited', 'BucklingSF', 'CVAngle_deg', ...
    'Valid'});

    function limit_kph = steer_speed_limit(Tf, Tr, current_kph)
        % Required steer angle grows as speed falls, so the smallest speed at
        % which the steering limit is still respected bounds the lap.
        inner_radius_m = path_radius_m - Tf / (2 * mm_per_m);
        outer_radius_m = path_radius_m + Tr / (2 * mm_per_m);
        required_inner = atan2d(params.L, inner_radius_m * mm_per_m);
        required_outer = atan2d(params.L, outer_radius_m * mm_per_m);
        required_max = max(required_inner, required_outer);

        if required_max <= config.skidpad_max_steer_deg
            limit_kph = inf;
        else
            limit_kph = 0;
        end
        limit_kph = min(limit_kph, current_kph);
    end

    function [Fz, utilisation] = four_wheel_state(Ay, direction, case_id)
        Kf = vehicle.K_phi_f(case_id);
        Kr = vehicle.K_phi_r(case_id);
        Ktotal = vehicle.K_phi_total(case_id);
        Tf = vehicle.T_f(case_id);
        Tr = vehicle.T_r(case_id);

        z_RA = params.z_RF + (params.z_RR - params.z_RF) * ...
            (1 - params.WD_f);
        M_R_per_g = params.m_s * g * ((params.h_s - z_RA) / mm_per_m);

        W_f_wheel = params.W_total * params.WD_f / 2;
        W_r_wheel = params.W_total * (1 - params.WD_f) / 2;

        dWf = Ay * params.m_uf * g * (params.h_uf / Tf) + ...
            Ay * params.m_s * g * params.WD_f * (params.z_RF / Tf) + ...
            (Kf / Ktotal) * M_R_per_g * Ay / (Tf / mm_per_m);
        dWr = Ay * params.m_ur * g * (params.h_ur / Tr) + ...
            Ay * params.m_s * g * (1 - params.WD_f) * ...
            (params.z_RR / Tr) + ...
            (Kr / Ktotal) * M_R_per_g * Ay / (Tr / mm_per_m);

        signed_front = direction * dWf;
        signed_rear = direction * dWr;
        Fz = [W_f_wheel - signed_front; W_f_wheel + signed_front; ...
            W_r_wheel - signed_rear; W_r_wheel + signed_rear];

        grip_front = @(load) max(params.mu_0f + params.dmu_dFz_f * ...
            (max(load, 0) - params.F_z0f), 0) .* max(load, 0);
        grip_rear = @(load) max(params.mu_0r + params.dmu_dFz_r * ...
            (max(load, 0) - params.F_z0r), 0) .* max(load, 0);

        capacity = [grip_front(Fz(1)); grip_front(Fz(2)); ...
            grip_rear(Fz(3)); grip_rear(Fz(4))];

        required_total = params.m_total * Ay * g;
        required_front = params.WD_f * required_total;
        required_rear = (1 - params.WD_f) * required_total;
        front_capacity = max(capacity(1) + capacity(2), eps);
        rear_capacity = max(capacity(3) + capacity(4), eps);
        required = [required_front * capacity(1) / front_capacity; ...
            required_front * capacity(2) / front_capacity; ...
            required_rear * capacity(3) / rear_capacity; ...
            required_rear * capacity(4) / rear_capacity];

        utilisation = (required ./ max(capacity, eps)).';
    end
end
